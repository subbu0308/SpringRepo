package com.dt.service;

import com.dt.bo.CompanyBo;
import com.dt.bo.JobBo;
import com.dt.command.PostJoBCommand;
import com.dt.dao.CompanyDao;
import com.dt.dao.JobDao;

public class JobService {

	private CompanyDao companyDao;
	private JobDao jobDao;
	
	
	public JobService(CompanyDao companyDao, JobDao jobDao) {
		super();
		this.companyDao = companyDao;
		this.jobDao = jobDao;
	}


	CompanyBo cbo = null;
	JobBo jbo = null;
	
	
	public void postJob(PostJoBCommand pjc) {
		try {
			cbo = new CompanyBo();
			cbo.setCompanyId(pjc.getCompanyId());
			cbo.setCompanyName(pjc.getCompanyName());
			cbo.setCompanyType(pjc.getCompanyType());
			cbo.setLocation(pjc.getLocation());		
			companyDao.saveCompany(cbo);
			
			jbo = new JobBo();
			jbo.setJobId(pjc.getJobId());
			jbo.setJobType(pjc.getJobType());
			jbo.setDesignation(pjc.getDesignation());
			jbo.setExperience(pjc.getExperience());
			jbo.setCompanyId(pjc.getCompanyId());		
			jobDao.saveJob(jbo);
			System.out.println("JOB POSTED SUCCESFULLY");
		}
		catch (Exception e) {
			System.out.println("Exception occured---"+e);
		}		
	}
}
