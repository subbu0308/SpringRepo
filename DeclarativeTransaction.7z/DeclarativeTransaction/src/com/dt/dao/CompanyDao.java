package com.dt.dao;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.dt.bo.CompanyBo;

public class CompanyDao {
	
	private NamedParameterJdbcTemplate jdbcTemplate;	
	
	private final String INSERT_COMPANY_DETAILS = "insert into customer(company_id,company_name,company_type,location) values(:companyId, :companyName, :companyType, :location)";
	
	public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}	
	
	public void saveCompany(CompanyBo cbo) {	
		cbo = new CompanyBo();	
		
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("companyId", cbo.getCompanyId());
		paramMap.put("companyName", cbo.getCompanyName());
		paramMap.put("companyType", cbo.getCompanyType());
		paramMap.put("location", cbo.getLocation());		
		jdbcTemplate.update(INSERT_COMPANY_DETAILS,paramMap);
		System.out.println("Company has been inserted successfully");
	
	}

}
