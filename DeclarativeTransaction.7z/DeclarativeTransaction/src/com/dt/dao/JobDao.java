package com.dt.dao;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.dt.bo.JobBo;

public class JobDao {
	
	private NamedParameterJdbcTemplate jdbcTemplate;	
	private final String INSER_JOB_DETAILS="insert into job(job_id, job_type, designation, experience, company_id) values(:jobId, :jobType, :designation, :experience, :companyid)";
	
	
	public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void saveJob(JobBo jobbo) {		
		Map<String, Object> jobMap = new HashMap<String, Object>();
		jobMap.put("jobId", jobbo.getJobId());
		jobMap.put("jobType",jobbo.getJobType());
		jobMap.put("designation", jobbo.getDesignation());
		jobMap.put("experience", jobbo.getExperience());
		jobMap.put("companyid", jobbo.getCompanyId());
		
		jdbcTemplate.update(INSER_JOB_DETAILS, jobMap);
		System.out.println();
		
	}

}
