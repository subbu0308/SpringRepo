package com.dt.controller;

import com.dt.command.PostJoBCommand;
import com.dt.service.JobService;

public class PostJobController {

	private JobService jobservice;
	
	
	public void setJobservice(JobService jobservice) {
		this.jobservice = jobservice;
	}


	public void createJob(PostJoBCommand pjc) {
		
		jobservice.postJob(pjc);
	}
}
