function SingleEnggApp(){
	var projectorderworktypes = '';  
	var attachmentsGrid = '';
	return {
		nfid : "",
		milestoneName : "",
		milestoneType : "",
		startdate : "",
		enddate : "",
		duedate : "",
		revisedEndDate : "",
		duration : "",
		milestonestatus: "",		
		requestType: "",
		projectType: "",
		orderType: "",
		workType: "",
		orderDesc: "",
		milestonesboolean : false,
		taskIdBoolean : false,
		assignedtoBoolean : false,
		filterboolean:false,
		childHTML : '',
		parentLevel : '',
		cnt : 0,
		level : 0,
		taskId:'', 
		assignedto : '',
		uuiflag : "null",
		attachmentsGrid: '',
		nfid : "",
		cipMilestoneTable : "",
		isCipProject : false,
		loadNetworkFulfillMent: function(nfid){
			this.nfid =  nfid;
			$('#networkfulfillment').load("networkfulfillment.jsp?nfid="+nfid); 
		},
		loadIndividualService : function(nfid,pageTag){
			this.nfid =  nfid;
			var _pageTag = (typeof pageTag != "undefined" && pageTag != "null")?"&pageTag="+pageTag:"";
			$('#networkfulfillment').load("commonIncludes.jsp?nfid="+nfid+""+_pageTag);
		},
		loadIndividualService1 : function(nfid,pageTag){
			this.nfid =  nfid;
			var _pageTag = (typeof pageTag != "undefined" && pageTag != "null")?"&pageTag="+pageTag:"";
			$('#networkfulfillment').load("commonIncludes1.jsp?nfid="+nfid+""+_pageTag);
		},
		initTabs : function(nfid,treeLoad){
			this.nfid =  nfid;
			this.loadAccordion();
			this.getChartData(nfid,treeLoad);
		},
		initialTabs : function(){
			this.loadAccordion();
		},
		initAccordions : function(nfid,treeLoad,pageTag){
			this.nfid =  nfid;
			this.loadAccordion(true,pageTag);
			this.getNFTree(nfid);
		},
		getNFTree : function(nfid){
			var _url = contextPath+"/rest/MilestoneViewService/getNfTree?nfid="+nfid,_params = {},_this = this;
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(response){
				_this.loadTree(response,nfid,true);
				$('#modal-one').hide();
			});
		},
		loadPage : function(data,content){
			var _pageName = data.flag,_data = $('#accordion').data(),_nfid = _data.nfid;
			$(content).show();
			switch(_pageName){
				case "summary":
						$(content).html('<div class="modal-dialog-container"><div class="modal-dialog"><div class="iconLoading"></div></div></div>');
						$(content).load("Summary.jsp?nfid="+_nfid+'&isSeperateApp=true',function(){
							$('.modal-dialog-container').hide();
							$(content).data('reload',false);
						});
						break;
				case "milestone":
						$(content).html('<div class="modal-dialog-container"><div class="modal-dialog"><div class="iconLoading"></div></div></div>');
						$(content).load("milestoneview.jsp?nfid="+_nfid+'&isSeperateApp=true',function(){
							$('.modal-dialog-container').hide();
							$(content).data('reload',false);
						});
						break;
				case "network":
						$(content).html('<div class="modal-dialog-container"><div class="modal-dialog"><div class="iconLoading"></div></div></div>');
						$(content).load("NetworkView.jsp?nfid="+_nfid+'&isSeperateApp=true',function(){
							$('.modal-dialog-container').hide();
							$(content).data('reload',false);
						});
						break;
				default:
			}
		},
		loadAccordion : function(needsIcon,pageTag){
			var _this = this;
			$( "#accordion" ).accordion({
				header : "h3",
				heightStyle : "content",
				collapsible: true,
				active : false,
				beforeActivate: function(event, ui) {
					var currHeader,currContent,isPanelSelected,_currentContentData;
					if(typeof needsIcon == "undefined"){
						if (ui.newHeader[0]) {
							currHeader  = ui.newHeader;
							currContent = currHeader.next('.ui-accordion-content');
						} else {
							currHeader  = ui.oldHeader;
							currContent = currHeader.next('.ui-accordion-content');
						}
						isPanelSelected = currHeader.attr('aria-selected') == 'true';
						currHeader.toggleClass('ui-corner-all',isPanelSelected).toggleClass('accordion-header-active ui-state-active ui-corner-top',!isPanelSelected).attr('aria-selected',((!isPanelSelected).toString()));
						currHeader.children('.ui-icon').toggleClass('ui-icon-triangle-1-e',isPanelSelected).toggleClass('ui-icon-triangle-1-s',!isPanelSelected);
						currContent.toggleClass('accordion-content-active',!isPanelSelected);    
						if (isPanelSelected) { currContent.slideUp(); }  else { currContent.slideDown(); }
					} else if(typeof needsIcon != "undefined") {
						if (ui.newHeader[0]) {
							currHeader  = ui.newHeader;
							currContent = currHeader.next('.ui-accordion-content');
						} else {
							currHeader  = ui.oldHeader;
							currContent = currHeader.next('.ui-accordion-content');
						}
						if($(currContent).data('empty') == "yes" || $(currContent).data('reload') == true){
							isPanelSelected = false;
						} else {
							isPanelSelected = currHeader.attr('aria-selected') == 'true';
						}
						currHeader.toggleClass('ui-corner-all',isPanelSelected).toggleClass('accordion-header-active ui-state-active ui-corner-top',!isPanelSelected).attr('aria-selected',((!isPanelSelected).toString()));
						currHeader.children('.ui-icon').toggleClass('ui-icon-triangle-1-e',isPanelSelected).toggleClass('ui-icon-triangle-1-s',!isPanelSelected);
						currContent.toggleClass('accordion-content-active',!isPanelSelected);    
						if (isPanelSelected && $(currContent).data('reload') == false) { 
							currContent.slideUp(); 
							console.log($(currContent).data('reload'));
						}  else {
							_currentContentData = $(currContent).data();
							if(_currentContentData.empty == "yes" || _currentContentData.reload == true){
								_this.loadPage($(currHeader).data(),currContent);
								console.log(_currentContentData.reload);
								$(currContent).data("empty","no");
							} else {
								currContent.slideDown(); 
							}
						}
					}
					return false;
				}
			});
			if(typeof pageTag != "undefined" && pageTag != "null"){
				this.triggerAccordion(pageTag);
			}
			if(typeof needsIcon != "undefined"){
				$('#accordion').find('.ui-accordion-header').append('<span class="openwindow">&nbsp;</span>');
				$('#accordion').find('.ui-accordion-header').append('<span class="reloadWindow1">&nbsp;</span>');
			} else {
				$('#accordion').find('h3.ui-accordion-header:eq(2)').append('<span class="CollapseAll" style="margin-right:5px;"></span>');
				$('#accordion').find('h3.ui-accordion-header:eq(2)').append('<span class="ExpandAll" style="margin-right:5px;"></span>');
				$('#accordion').find('h3.ui-accordion-header:eq(2)').append('<span class="reloadWindow">&nbsp;</span>');
			}
			$('#accordion').find('h3.ui-accordion-header span.ExpandAll').click(function(){
				_this.expandAll();
				return false;
			});		
			$('#accordion').find('h3.ui-accordion-header span.CollapseAll').click(function(){
				_this.collapseAll();
				return false;
			});	
			$('#accordion').find('h3.ui-accordion-header span.reloadWindow1').click(function(){
				_this.reloadSection(this);
				return false;
			});
			$('#accordion').find('h3.ui-accordion-header span.openwindow').click(function(){
				_this.openSection(this);
				return false;
			});
			$('#accordion').find('h3.ui-accordion-header span.reloadWindow').click(function(){
				_this.filterboolean = false;
				_this.milestonesboolean=false;
				_this.taskIdBoolean = false;
				_this.assignedtoBoolean=false;
				$('.milestones').find('.filter input').val('');
				$("#milestonestatus").val('');
				$("#milestonetype").prop('selectedIndex',0);
				_this.milestoneName = "";
				_this.milestoneType = "";
				_this.startdate =  "";
				_this.enddate = "";
				_this.duedate =  "";
				_this.milestonestatus = "";
				_this.getMileStoneData();
				return false;
			});	
		},
		openSection : function(eleRef){
			var pageTag = $(eleRef).parent().data("flag"),_url = "",_nfid = $('#accordion').data("nfid");
			switch(pageTag){
				case "summary":
					_url = "Summary.jsp?nfid="+_nfid+"&uuiFlag=true";
					break;
				case "milestone":
					_url = "milestoneview.jsp?nfid="+_nfid+"&uuiFlag=true";
					break;
				case "network":
					_url = "NetworkView.jsp?nfid="+_nfid+"&uuiFlag=true";
					break;
				default:
			}
			console.log("url is");
			console.log(_url);
			window.open(_url,"_new","width=900px,height=500px");
		},
		reloadSection : function(eleRef){
			var index = 0,pageTag = $(eleRef).parent().data("flag");
			switch(pageTag){
				case "summary":
					index = 0;
					break;
				case "milestone":
					index = 1;
					break;
				case "network":
					index = 2;
					break;
				default:
			}
			$(eleRef).parent().next('.ui-accordion-content').data("reload",true);
			$('#accordion').find('h3.ui-accordion-header').eq(index).trigger('click');
		},
		triggerAccordion : function(pageTag){
			var index = 0;
			switch(pageTag){
				case "summary":
					index = 0;
					break;
				case "milestone":
					index = 1;
					break;
				case "network":
					index = 2;
					break;
				default:
			}
			$('#accordion').find('h3.ui-accordion-header').eq(index).trigger('click');
		},
		loadAFESummaryData : function(afe){
			var _url =  contextPath+"/rest/MilestoneViewService/getAfeSummaryByAFE?afe="+afe,_params = {},_this = this;
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(response){
				$('#afeDetails').find('.businessCase').text(response.results[0].BusinessCase);		
				$('#afeDetails').find('.caseName').text(response.results[0].CaseTitle);
				$('#afeDetails').find('.AfeProject').text(response.results[0].afeProjectNum);
				$('#afeDetails').find('.ProjectName').text(response.results[0].ProjectTitle);
				$('#afeDetails').find('.ProjectManager').text(response.results[0].projectMANAGER);    
				$('#afeDetails').find('.AfeRelDate').text(response.results[0].clli);   
				$('#afeDetails').find('.AfeStatus').text(response.results[0].SYSTEMSTATUS);
				$('#afeDetails').find('.AfeBudgetAmount').text(response.results[0].AFEBUDGETAMOUNT);
				$('#afeDetails').find('.AfeActalSpend').text(response.results[0].AFEACTUALSPENT);
				$('#afeDetails').find('.Commit').text(response.results[0].COMMITMENT);
			});
		}, 
		loadvSAPSummaryData : function(vSAPID){
			var _url =  contextPath+"/rest/MilestoneViewService/getVsapSummaryData?vsapId="+vSAPID,_params = {},_this = this;
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(response){
				$('#vsapDetails').find('.vsapProject').text(response.results[0].VSAP_PROJECT_ID);		
				$('#vsapDetails').find('.budgetOwner').text(response.results[0].PROJECT_MANAGER);
				$('#vsapDetails').find('.budgetAmount').text(response.results[0].BUDGET);
				$('#vsapDetails').find('.actualSpend').text(response.results[0].ACTUAL);
				$('#vsapDetails').find('.commit').text(response.results[0].COMMITMENT);    
			});
		},
		
		
		loadSummaryData : function(nfid){
			var _url = contextPath+"/rest/NetworkFulfillmentService/getSummaryData?nfid="+nfid,_params = {},_this = this;
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(response){
				var _status = "";
				$('#projectFrameDetails').find('.projname').text(_this.isEmptyValue(response.projectName));
				_status = ($.trim(response.status).toLowerCase().split(" ").length>0)?$.trim(response.projectStatus).toLowerCase().split(" ").join(""):$.trim(response.projectStatus).toLowerCase();
				$('#projectFrameDetails').find('.Status i.iconstatus').addClass(_this.getProjectStatusIcon(_status));
				$('#projectFrameDetails').find('.Status span').text(response.projectStatus);
				$('#projectFrameDetails').find('.createdBy').text(_this.isEmptyValue(response.userName));
				$('#projectFrameDetails').find('.created_date').text(_this.isEmptyValue(response.createdDate));
				$('#projectFrameDetails').find('.start_date').text(_this.isEmptyValue(response.startDate));
				$('#projectFrameDetails').find('.due_date').text(_this.isEmptyValue(response.dueDate));
				$('#projectFrameDetails').find('.nfId').text(_this.isEmptyValue(response.nfid));
				$('#projectFrameDetails').find('.desc').text(_this.isEmptyValue(response.projectDescription));
				$('#projectDetailsFrameDetails').find('.cllicode').text(_this.isEmptyValue(response.clli));
				$('#projectDetailsFrameDetails').find('.networkActivity').text(_this.isEmptyValue(response.networkActivityName));
				$('#projectDetailsFrameDetails').find('.engineeringDiscipline').text(_this.isEmptyValue(response.engineeringDiscipline));
				$('#projectDetailsFrameDetails').find('.projectType').text(_this.isEmptyValue(response.projectTypeName));
				$('#projectDetailsFrameDetails').find('.serviceType').text(_this.isEmptyValue(response.serviceTypeName));
				$('#projectDetailsFrameDetails').find('.clarityId').text(_this.isEmptyValue(response.clarityProjectId));
				$('#projectDetailsFrameDetails').find('.bonitacaseId').text(_this.isEmptyValue(_this.checkCaseId($.trim(response.bonitaCaseId))));
				$('#projectDetailsFrameDetails').find('.lob').text(_this.isEmptyValue(_this.checkLob($.trim(response.lob))));
			});
		},
		loadProjectSummaryData : function(projectId){
			$('#createNFPROJECT').hide();
			$('#budgetRegion').hide();
			$('#projectDetail_loading').show();
			var _url = contextPath+"/rest/NetworkFulfillmentService/getProjectSummaryDataByProjectId?projectId="+projectId,_params = {},_this = this;
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(response){
				$('#createNFPROJECT').show();
				var _status = ""; 
				console.log("the payload details: "+JSON.stringify(response));
				var is_VZT_VZB=(typeof response.clliObject != 'undefined') ?  response.clliObject.is_VZT_VZB : '';
				$('#projectFrameDetails').find('.nfid').text(_this.isEmptyValue(response.nfid));
				$('#projectFrameDetails').find('.projname').text(_this.isEmptyValue(response.projectName));
				if(response.programName != "undefined" && response.programName != ""){
					$('#projectFrameDetails').find('.programName').text(response.programName);
				} else {
					$('#projectFrameDetails').find('.programName').text("N/A");
				}
				_status = ($.trim(response.status).toLowerCase().split(" ").length>0)?$.trim(response.projectStatus).toLowerCase().split(" ").join(""):$.trim(response.projectStatus).toLowerCase();
				$('#projectFrameDetails').find('.Status i.iconstatus').addClass(_this.getProjectStatusIcon(_status));
				$('#projectFrameDetails').find('.Status span').text(response.projectStatus);
				if(typeof response.payloadInfo != "undefined"){
					$('#projectFrameDetails').find('.createdBy').text(response.payloadInfo.createdBy);

				} else {
					$('#projectFrameDetails').find('.createdBy').text("");
				}
				$('#projectFrameDetails').find('.created_date').text(_this.isEmptyValue(response.createdDate));
				$('#projectFrameDetails').find('.start_date').text(_this.isEmptyValue(response.startDate));
				$('#projectFrameDetails').find('.due_date').text(_this.isEmptyValue(response.dueDate));
				$('#projectFrameDetails').find('.desc').html(_this.isEmptyValue(response.projectDescription).replace(/\n/g,"<br />"));
				$('#projectFrameDetails').find('.cllicode').text(_this.isEmptyValue("N/A"));
				$('#projectFrameDetails').find('.networkActivity').text(_this.isEmptyValue(response.networkActivityName));
				$('#projectFrameDetails').find('.engineeringDiscipline').text(_this.isEmptyValue(response.engineeringDiscipline));
				$('#projectFrameDetails').find('.projectType').text(_this.isEmptyValue(response.projectTypeName));
				if(response.serviceTypeName == "Add Card-StandAlone TEO"){
					if(response.payloadInfo.ServiceType == "Laser Adds")
					{
					$('#projectFrameDetails').find('.serviceType').text("Laser Adds");
					}
				else{
					$('#projectFrameDetails').find('.serviceType').text("Add Card");
				}
				} else{
					$('#projectFrameDetails').find('.serviceType').text(_this.isEmptyValue(response.serviceTypeName));	
				}
				if(typeof response.payloadInfo != "undefined"){
					if(typeof response.payloadInfo.state != "undefined" && response.payloadInfo.state != ""){
						$('#projectFrameDetails').find('.telemetryRequired').text(_this.isEmptyValue(response.payloadInfo.telemetryRequired));
						$('#projectFrameDetails').find('.networkCircuitRequired').text(_this.isEmptyValue(response.payloadInfo.networkCircuitRequired));
						$('#projectFrameDetails').find('.test1').text(_this.isEmptyValue(response.payloadInfo.test1Required)); 
						$('#projectFrameDetails').find('.test2').text(_this.isEmptyValue(response.payloadInfo.test2Required));
						$('#projectFrameDetails').find('.meshRequired').text(_this.isEmptyValue(response.payloadInfo.meshRequired));
						$('#projectFrameDetails').find('.cbsrequired').text(_this.isEmptyValue(response.payloadInfo.cbscneRequired));
						$('#projectFrameDetails').find('.shelfBayAdded').text(_this.isEmptyValue(response.payloadInfo.pscRequestRequired));
						$('#projectFrameDetails').find('.inventoryRequired').text(_this.isEmptyValue(response.payloadInfo.inventoryRequired));
						$('#projectFrameDetails').find('.transportRequired').text(_this.isEmptyValue(response.payloadInfo.transportRequired));
						if(response.engineeringDiscipline == "FE&C"){
							$('#budgetRegion').show();
							console.log("Psc sliders and Questions");
							console.log("budget region : "+response.payloadInfo.budgetRegion);
							$('#networkCircuitRequired').hide();
							$('#equipmentAcceptanceTesting').hide();
							$('#networkAcceptanceTesting').hide();
							$('#meshRequired').hide();
							$('#cbsrequired').hide();
							$('#shelfBayAdded').hide();
							$('#facilityPrep').hide();
							$('#vztTirksScid').hide();
							$('#colocation').hide();
							$('#fiberworkrequired').hide();
							$('.teoRequiredCls').hide();
							$('#vzbTirksScid').hide();
							$('#vztnetworkPlan').hide();
							$('#vzttransport').hide();
							$('#vztinventory').hide();
							$('#cdcRequired').hide();
							$('#teoRequired').hide();
							$('#projectFrameDetails').find('.budgetRegion').text(response.payloadInfo.budgetRegion);
							//$('#projectFrameDetails').find('.budgetRegion').text(_this.isEmptyValue(response.payloadInfo.budgetRegion));
							$('#projectFrameDetails').find('.dcPower').text(_this.isEmptyValue(response.payloadInfo.dcPower));
							$('#projectFrameDetails').find('.hvac').text(_this.isEmptyValue(response.payloadInfo.hvac));
							$('#projectFrameDetails').find('.generator').text(_this.isEmptyValue(response.payloadInfo.generator)); 
							$('#projectFrameDetails').find('.acService').text(_this.isEmptyValue(response.payloadInfo.acService));
							$('#projectFrameDetails').find('.other').text(_this.isEmptyValue(response.payloadInfo.other));
							$('#projectFrameDetails').find('.criticalPath').text(_this.isEmptyValue(response.payloadInfo.criticalPath));
							
							$('#projectFrameDetails').find('.what').text(_this.isEmptyValue(response.payloadInfo.what));
							$('#projectFrameDetails').find('.why').text(_this.isEmptyValue(response.payloadInfo.why));
							$('#projectFrameDetails').find('.whyNow').text(_this.isEmptyValue(response.payloadInfo.whyNow)); 
							$('#projectFrameDetails').find('.whyThisWay').text(_this.isEmptyValue(response.payloadInfo.whyThisWay));
							$('#projectFrameDetails').find('.addlnProjDtls').text(_this.isEmptyValue(response.payloadInfo.additionalProjectDetails));
						}else{
							$('#budgetRegion').hide();
							$('#dcPower').hide();
							$('#hvac').hide();
							$('#generator').hide();
							$('#acService').hide();
							$('#other').hide();
							$('#criticalPath').hide();
							$('#what').hide();
							$('#why').hide();
							$('#whyNow').hide();
							$('#whyThisWay').hide();
							$('#addlnProjDtls').hide();
						}
						if(typeof response.payloadInfo.networkPlanRequired != "undefined" && response.payloadInfo.networkPlanRequired != ""){
							if(typeof is_VZT_VZB != "undefined" && is_VZT_VZB != "" && is_VZT_VZB == "VZT"){
								$('#projectFrameDetails').find('#vztnetworkPlan').show();
								$('#projectFrameDetails').find('.networkPlanRequired').text(_this.isEmptyValue(response.payloadInfo.networkPlanRequired));
							} else {
								$('#projectFrameDetails').find('#vztnetworkPlan').hide();
						       }
							}
						if(typeof response.payloadInfo.facilityPrepRequired != "undefined" && response.payloadInfo.facilityPrepRequired != ""){
							if(typeof is_VZT_VZB != "undefined" && is_VZT_VZB != "" && is_VZT_VZB != "VZT"){
							$('#projectFrameDetails').find('.facilityPrepReq').text(_this.isEmptyValue(response.payloadInfo.facilityPrepRequired));
							} else{
								//facilityPrep
								$('#projectFrameDetails').find('#facilityPrep').hide();
							}
						} else if(typeof response.payloadInfo.prepWorkRequired != "undefined" &&  response.payloadInfo.prepWorkRequired != ""){
							if(typeof is_VZT_VZB != "undefined" && is_VZT_VZB != "" && is_VZT_VZB != "VZT"){
							$('#projectFrameDetails').find('.facilityPrepReq').text(_this.isEmptyValue(response.payloadInfo.prepWorkRequired));
							} else {
								$('#projectFrameDetails').find('#facilityPrep').hide();
							}
						} else {
							$('#projectFrameDetails').find('.facilityPrepReq').text('N/A');  
						}
						if(typeof is_VZT_VZB != "undefined" && is_VZT_VZB != "" && is_VZT_VZB != "VZT"){
							$('#projectFrameDetails').find('.colocationReq').text(_this.isEmptyValue(response.payloadInfo.colocationRequired));
							$('#projectFrameDetails').find('.fiberReq').text(_this.isEmptyValue(response.payloadInfo.fiberWorkRequired));
							$('#projectFrameDetails').find('#vztTirksScid').hide();
							$('#projectFrameDetails').find('#vzttransport').hide();
							$('#projectFrameDetails').find('#vztinventory').hide();
							$('#projectFrameDetails').find('#telemetryRequired').hide();
							$('#projectFrameDetails').find('#shelfBayAdded').hide();
							$('#projectFrameDetails').find('#cbsrequired').hide();
							$('#cdcRequired').hide();
							
							if(typeof response.payloadInfo.SCIDRequired != "undefined" && response.payloadInfo.SCIDRequired != ""){
								var ScidVal=(response.payloadInfo.SCIDRequired == 'Y')?response.payloadInfo.SCIDRequired:response.payloadInfo.SCIDRequired;
								$('#projectFrameDetails').find('.tirksScidReq').text(ScidVal);
							} else {
								$('#projectFrameDetails').find('.tirksScidReq').text("N/A");	
							}
							
						} else if(typeof is_VZT_VZB != "undefined" && is_VZT_VZB != "" && is_VZT_VZB == "VZT"){
							$('#projectFrameDetails').find('#colocation').hide();
							$('#projectFrameDetails').find('#fiberworkrequired').hide();
							$('#projectFrameDetails').find('#vzbTirksScid').hide();
							$('#projectFrameDetails').find('#vzbtransport').hide();
							$('#projectFrameDetails').find('#vzbinventory').hide();
							$('#projectFrameDetails').find('#vzbshelfBayAdded').hide();
							$('#projectFrameDetails').find('#vzbtelemetryRequired').hide();
							$('#projectFrameDetails').find('#vzbcbsrequired').hide();
							$('#cdcRequired').hide();
							
							if(typeof response.payloadInfo.SCIDRequired != "undefined" && response.payloadInfo.SCIDRequired != ""){
								var ScidVal=(response.payloadInfo.SCIDRequired == 'Y')?response.payloadInfo.SCIDRequired:response.payloadInfo.SCIDRequired;
								$('#projectFrameDetails').find('.tirksScidReq').text(ScidVal);
							} else {
								$('#projectFrameDetails').find('.tirksScidReq').text("N/A");	
							}
						}
						if(typeof response.payloadInfo.standAloneTEORequired != "undefined" && response.payloadInfo.standAloneTEORequired != ""){
							if(response.serviceTypeName == "Add Card" || response.serviceTypeName == "Add Card-StandAlone TEO"){
								$('#projectFrameDetails').find('.teoRequired').text(response.payloadInfo.standAloneTEORequired);
							} else {
								$('#projectFrameDetails').find('.teoRequired').text("N/A");
							}
						} else {
							$('#projectFrameDetails').find('.teoRequired').text("N/A");	
						}
						if(typeof response.payloadInfo.projectID != "undefined" && response.payloadInfo.projectID != ""){
							$('#projectFrameDetails').find('.afeId').text(response.payloadInfo.projectID);
						} else {
							$('#projectFrameDetails').find('.afeId').text("N/A");	
						}
						
						if(typeof response.payloadInfo.advCompleteDate != "undefined" && response.payloadInfo.advCompleteDate != ""){
							
							$('#projectFrameDetails').find('.advCompleteDate').text(response.payloadInfo.advCompleteDate);
						} else {
							$('#projectFrameDetails').find('.advCompleteDate').text("N/A");	
						}
						
						if(typeof response.clliZObject != "undefined" && $.isEmptyObject(response.clliZObject) == false){
							$('#projectFrameDetails').find('.cllicodez').text(_this.isEmptyValue($.trim(response.clliZObject.CLLI)));
							$('#projectFrameDetails').find('.cityz').text(_this.isEmptyValue($.trim(response.clliZObject.CITY)));
							$('#projectFrameDetails').find('.streetz').text(_this.isEmptyValue($.trim(response.clliZObject.STREET)));
							$('#projectFrameDetails').find('.statez').text(_this.isEmptyValue($.trim(response.clliZObject.STATE)));
							$('#projectFrameDetails').find('.countrycodez').text(_this.isEmptyValue($.trim(response.clliZObject.COUNTRYCODE)));
							$('#projectFrameDetails').find('.zipz').text(_this.isEmptyValue($.trim(response.clliZObject.ZIP)));
							$('#projectFrameDetails').find('.locationnamez').text(_this.isEmptyValue($.trim(response.clliZObject.LOCATIONNAME)));
						} else {
							$('#projectFrameDetails').find('.optional1').hide();
						}
						if(typeof response.payloadInfo.cdcRequired != "undefined" && response.payloadInfo.cdcRequired != ""){
							$('#projectFrameDetails').find('.cdcRequired').text(response.payloadInfo.cdcRequired);
						} else {
						$('#projectFrameDetails').find('.cdcRequired').text("N/A");	
						}
						$('#milestoneviewpage').attr('src', contextPath+"/milestonelist.jsp?nfid="+_this.isEmptyValue(response.nfid)+"&uuiFlag=true");
					} else {
						$('#projectFrameDetails').find('.optional').hide();
						$('#milestoneviewpage').attr('src', contextPath+"/milestoneview.jsp?nfid="+_this.isEmptyValue(response.nfid)+"&uuiFlag=true");
					}
				} else {
					$('#projectFrameDetails').find('.telemetryRequired').text("N/A");
					$('#projectFrameDetails').find('.networkCircuitRequired').text("N/A");
					$('#projectFrameDetails').find('.test1').text("N/A");
					$('#projectFrameDetails').find('.test2').text("N/A");
					$('#projectFrameDetails').find('.meshRequired').text("N/A");
					$('#projectFrameDetails').find('.cbsrequired').text("N/A");
					$('#projectFrameDetails').find('.shelfBayAdded').text("N/A");
					$('#projectFrameDetails').find('.facilityPrepReq').text("N/A");
					$('#projectFrameDetails').find('.colocationReq').text("N/A");
					$('#projectFrameDetails').find('.fiberReq').text("N/A");
					$('#projectFrameDetails').find('.tirksScidReq').text("N/A");
					$('#projectFrameDetails').find('.teoRequired').text("N/A");
					$('#projectFrameDetails').find('.networkPlanRequired').text("N/A");
					$('#projectFrameDetails').find('.inventoryRequired').text("N/A");
					$('#projectFrameDetails').find('.transportRequired').text("N/A");
					$('#projectFrameDetails').find('.cdcRequired').text("N/A");
				}
				$('#projectFrameDetails').find('.lob').text(_this.isEmptyValue(_this.checkLob($.trim(response.lob))));
				if(typeof response.clliObject != 'undefined'){
					$('#projectFrameDetails').find('.cllicode').text(_this.isEmptyValue($.trim(response.clliObject.CLLI)));
					$('#projectFrameDetails').find('.city').text(_this.isEmptyValue($.trim(response.clliObject.CITY)));
					$('#projectFrameDetails').find('.street').text(_this.isEmptyValue($.trim(response.clliObject.STREET)));
					$('#projectFrameDetails').find('.state').text(_this.isEmptyValue($.trim(response.clliObject.STATE)));
					$('#projectFrameDetails').find('.countrycode').text(_this.isEmptyValue($.trim(response.clliObject.COUNTRYCODE)));
					$('#projectFrameDetails').find('.zip').text(_this.isEmptyValue($.trim(response.clliObject.ZIP)));
					$('#projectFrameDetails').find('.locationname').text(_this.isEmptyValue($.trim(response.clliObject.LOCATIONNAME)));
				} else{
					$("#headingThree").hide();
					$("#locationADetailsFlexGrid").hide();
				}
				$('#projectDetail_loading').hide();
				$('#projectSummaryToHideDetails').show();
			});
		},
		loadProjectSummaryDataByNFID : function(nfid){
				$('#projectDetail_loading').show();
			var _url = contextPath+"/rest/NetworkFulfillmentService/getProjectSummaryData?nfid="+nfid,_params = {},_this = this;
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(response){
				$('#projectDetail_loading').hide();
				var _status = ""; 
				if(typeof response.payloadInfo != "undefined")
				{
				var is_VZT_VZB=response.payloadInfo.lob;
				}
				$('#projectFrameDetails').find('.nfid').text(_this.isEmptyValue(response.nfid));
				$('#projectFrameDetails').find('.projname').text(_this.isEmptyValue(response.projectName));
				if(response.programName != "undefined" && response.programName != ""){
					$('#projectFrameDetails').find('.programName').text(response.programName);
				} else {
					$('#projectFrameDetails').find('.programName').text("N/A");
				}
				_status = ($.trim(response.status).toLowerCase().split(" ").length>0)?$.trim(response.projectStatus).toLowerCase().split(" ").join(""):$.trim(response.projectStatus).toLowerCase();
				$('#projectFrameDetails').find('.Status i.iconstatus').addClass(_this.getProjectStatusIcon(_status));
				$('#projectFrameDetails').find('.Status span').text(response.projectStatus);
				if(typeof response.payloadInfo != "undefined"){
					$('#projectFrameDetails').find('.createdBy').text(response.payloadInfo.createdBy);
				} else {
					$('#projectFrameDetails').find('.createdBy').text("");
				}
				$('#projectFrameDetails').find('.created_date').text(_this.isEmptyValue(response.createdDate));
				$('#projectFrameDetails').find('.start_date').text(_this.isEmptyValue(response.startDate));
				$('#projectFrameDetails').find('.due_date').text(_this.isEmptyValue(response.dueDate));
				$('#projectFrameDetails').find('.desc').text(_this.isEmptyValue(response.projectDescription));
				$('#projectFrameDetails').find('.cllicode').text(_this.isEmptyValue("N/A"));
				$('#projectFrameDetails').find('.networkActivity').text(_this.isEmptyValue(response.networkActivityName));
				$('#projectFrameDetails').find('.engineeringDiscipline').text(_this.isEmptyValue(response.engineeringDiscipline));
				$('#projectFrameDetails').find('.projectType').text(_this.isEmptyValue(response.projectTypeName));
				if(response.serviceTypeName == "Add Card-StandAlone TEO"){
					if(response.payloadInfo.ServiceType == "Laser Adds")
						{ 
						
						$('#projectFrameDetails').find('.serviceType').text("Laser Adds");
						}
					else{
						$('#projectFrameDetails').find('.serviceType').text("Add Card");
					}	
				} else{
					$('#projectFrameDetails').find('.serviceType').text(_this.isEmptyValue(response.serviceTypeName));	
				}
				if(typeof response.payloadInfo != "undefined"){
					if(typeof response.payloadInfo.state != "undefined" && response.payloadInfo.state != ""){
						$('#projectFrameDetails').find('.telemetryRequired').text(_this.isEmptyValue(response.payloadInfo.telemetryRequired));
						$('#projectFrameDetails').find('.networkCircuitRequired').text(_this.isEmptyValue(response.payloadInfo.networkCircuitRequired));
						$('#projectFrameDetails').find('.test1').text(_this.isEmptyValue(response.payloadInfo.test1Required)); 
						$('#projectFrameDetails').find('.test2').text(_this.isEmptyValue(response.payloadInfo.test2Required));
						$('#projectFrameDetails').find('.meshRequired').text(_this.isEmptyValue(response.payloadInfo.meshRequired));
						$('#projectFrameDetails').find('.cbsrequired').text(_this.isEmptyValue(response.payloadInfo.cbscneRequired));
						$('#projectFrameDetails').find('.shelfBayAdded').text(_this.isEmptyValue(response.payloadInfo.pscRequestRequired));
						$('#projectFrameDetails').find('.networkPlanRequired').text(_this.isEmptyValue(response.payloadInfo.networkPlanRequired));
						$('#projectFrameDetails').find('.inventoryRequired').text(_this.isEmptyValue(response.payloadInfo.inventoryRequired));
						$('#projectFrameDetails').find('.transportRequired').text(_this.isEmptyValue(response.payloadInfo.transportRequired));
						if(typeof response.payloadInfo.lob != 'undefined' && response.payloadInfo.lob != 'T'){
							if(typeof response.payloadInfo.facilityPrepRequired != "undefined" && response.payloadInfo.facilityPrepRequired != ""){
								if(typeof is_VZT_VZB != "undefined" && is_VZT_VZB != "" && is_VZT_VZB != "VZT"){
									$('#projectFrameDetails').find('.facilityPrepReq').text(_this.isEmptyValue(response.payloadInfo.facilityPrepRequired));
								} else{
										//facilityPrep
										$('#projectFrameDetails').find('#facilityPrep').hide();
									}
							} else if(typeof response.payloadInfo.prepWorkRequired != "undefined" &&  response.payloadInfo.prepWorkRequired != ""){
								if(typeof is_VZT_VZB != "undefined" && is_VZT_VZB != "" && is_VZT_VZB != "VZT"){
									$('#projectFrameDetails').find('.facilityPrepReq').text(_this.isEmptyValue(response.payloadInfo.prepWorkRequired));
									} else {
										$('#projectFrameDetails').find('#facilityPrep').hide();
									}
							} else {
								$('#projectFrameDetails').find('.facilityPrepReq').text('N/A');  
							}
							$('#projectFrameDetails').find('.colocationReq').text(_this.isEmptyValue(response.payloadInfo.colocationRequired));
							$('#projectFrameDetails').find('.fiberReq').text(_this.isEmptyValue(response.payloadInfo.fiberWorkRequired));
							$('#projectFrameDetails').find('#vztTirksScid').hide();
							$('#projectFrameDetails').find('#vztnetworkPlan').hide();
							$('#projectFrameDetails').find('#vzttransport').hide();
							$('#projectFrameDetails').find('#vztinventory').hide();
							$('#projectFrameDetails').find('#vzbtransport').show();
							$('#projectFrameDetails').find('#vzbinventory').show();
							
						} else {
							if(typeof response.payloadInfo.lob != 'undefined' && response.payloadInfo.lob == 'T'){
							$('#projectFrameDetails').find('.facilityPrepReq').hide();
							$('#projectFrameDetails').find('.colocationReq').hide();
							$('#projectFrameDetails').find('.fiberReq').hide();
							$('#projectFrameDetails').find('#vztTirksScid').show(); 
							$('#projectFrameDetails').find('#vzbTirksScid').hide();
							$('#projectFrameDetails').find('#colocation').hide();
							$('#projectFrameDetails').find('#fiberworkrequired').hide();
							$('#projectFrameDetails').find('#facilityPrep').hide();
							$('#projectFrameDetails').find('#vztnetworkPlan').show();
							$('#projectFrameDetails').find('#vzttransport').show();
							$('#projectFrameDetails').find('#vztinventory').show();
							$('#projectFrameDetails').find('#vzbtransport').hide();
							$('#projectFrameDetails').find('#vzbinventory').hide();
							}
						}
						if(typeof response.payloadInfo.standAloneTEORequired != "undefined" && response.payloadInfo.standAloneTEORequired != ""){
							if(response.serviceTypeName == "Add Card" || response.serviceTypeName == "Add Card-StandAlone TEO"){
								$('#projectFrameDetails').find('.teoRequired').text(response.payloadInfo.standAloneTEORequired);
							} else {
								$('#projectFrameDetails').find('.teoRequired').text("N/A");
							}
						} else {
							$('#projectFrameDetails').find('.teoRequired').text("N/A");	
						}
						if(typeof response.payloadInfo.SCIDRequired != "undefined" && response.payloadInfo.SCIDRequired != ""){
							var ScidVal=(response.payloadInfo.SCIDRequired == 'Y')?response.payloadInfo.SCIDRequired:response.payloadInfo.SCIDRequired;
							$('#projectFrameDetails').find('.tirksScidReq').text(ScidVal);
						} else {
							$('#projectFrameDetails').find('.tirksScidReq').text("N/A");	
						}
						if(typeof response.payloadInfo.projectID != "undefined" && response.payloadInfo.projectID != ""){
							$('#projectFrameDetails').find('.afeId').text(response.payloadInfo.projectID);
						} else {
							$('#projectFrameDetails').find('.afeId').text("N/A");	
						}
						if(typeof response.clliZObject != "undefined" && $.isEmptyObject(response.clliZObject) == false){
							$('#projectFrameDetails').find('.cllicodez').text(_this.isEmptyValue($.trim(response.clliZObject.CLLI)));
							$('#projectFrameDetails').find('.cityz').text(_this.isEmptyValue($.trim(response.clliZObject.CITY)));
							$('#projectFrameDetails').find('.streetz').text(_this.isEmptyValue($.trim(response.clliZObject.STREET)));
							$('#projectFrameDetails').find('.statez').text(_this.isEmptyValue($.trim(response.clliZObject.STATE)));
							$('#projectFrameDetails').find('.countrycodez').text(_this.isEmptyValue($.trim(response.clliZObject.COUNTRYCODE)));
							$('#projectFrameDetails').find('.zipz').text(_this.isEmptyValue($.trim(response.clliZObject.ZIP)));
							$('#projectFrameDetails').find('.locationnamez').text(_this.isEmptyValue($.trim(response.clliZObject.LOCATIONNAME)));
						} else {
							$('.project-summary-uui2').find('.optional1').hide();
						}
						if(typeof response.payloadInfo.cdcRequired != "undefined" && response.payloadInfo.cdcRequired != ""){
								$('#projectFrameDetails').find('.cdcRequired').text(response.payloadInfo.cdcRequired);
						} else {
							$('#projectFrameDetails').find('.cdcRequired').text("N/A");	
						}
						$('#milestoneviewpage').attr('src', contextPath+"/milestonelist.jsp?nfid="+_this.isEmptyValue(response.nfid)+"&uuiFlag=true");
					} else {
						$('.project-summary-uui2').find('.optional').hide();
						$('#milestoneviewpage').attr('src', contextPath+"/milestoneview.jsp?nfid="+_this.isEmptyValue(response.nfid)+"&uuiFlag=true");
					}
				} else {
					$('#projectFrameDetails').find('.telemetryRequired').text("N/A");
					$('#projectFrameDetails').find('.networkCircuitRequired').text("N/A");
					$('#projectFrameDetails').find('.test1').text("N/A");
					$('#projectFrameDetails').find('.test2').text("N/A");
					$('#projectFrameDetails').find('.meshRequired').text("N/A");
					$('#projectFrameDetails').find('.cbsrequired').text("N/A");
					$('#projectFrameDetails').find('.shelfBayAdded').text("N/A");
					$('#projectFrameDetails').find('.facilityPrepReq').text("N/A");
					$('#projectFrameDetails').find('.colocationReq').text("N/A");
					$('#projectFrameDetails').find('.fiberReq').text("N/A");
					$('#projectFrameDetails').find('.tirksScidReq').text("N/A");
					$('#projectFrameDetails').find('.networkPlanRequired').text("N/A");
					$('#projectFrameDetails').find('.inventoryRequired').text("N/A");
					$('#projectFrameDetails').find('.transportRequired').text("N/A");
					$('#projectFrameDetails').find('.cdcRequired').text("N/A");
				}
				$('#projectFrameDetails').find('.lob').text(_this.isEmptyValue(_this.checkLob($.trim(response.lob))));
				$('#projectFrameDetails').find('.cllicode').text(_this.isEmptyValue($.trim(response.clliObject.CLLI)));
				$('#projectFrameDetails').find('.city').text(_this.isEmptyValue($.trim(response.clliObject.CITY)));
				$('#projectFrameDetails').find('.street').text(_this.isEmptyValue($.trim(response.clliObject.STREET)));
				$('#projectFrameDetails').find('.state').text(_this.isEmptyValue($.trim(response.clliObject.STATE)));
				$('#projectFrameDetails').find('.countrycode').text(_this.isEmptyValue($.trim(response.clliObject.COUNTRYCODE)));
				$('#projectFrameDetails').find('.zip').text(_this.isEmptyValue($.trim(response.clliObject.ZIP)));
				$('#projectFrameDetails').find('.locationname').text(_this.isEmptyValue($.trim(response.clliObject.LOCATIONNAME)));
			});
		},
		checkLob : function(lob){
			return (typeof lob != "undefined" && lob == 'T') ? "VZT" : (typeof lob != "undefined" && lob == 'B') ? "VZB" : (typeof lob != "undefined" && lob == 'C') ? "C" : "Unknown";
		},
		checkLobForChar : function(lob){
			return (typeof lob != "undefined" && lob == 'T')?"VZT":"VZB";
		},
		checkCaseId : function(caseId){
			return (typeof caseId != "undefined" && caseId == 0)?"NA":caseId;
		},
		init : function(nfid,type){
			this.nfid = nfid;
			if(typeof type != "undefined" && type=="cip"){
				this.isCipProject = true;
			} else {
				this.isCipProject = false;
			}
			this.getMileStoneData(type);
			this.attachEvents();
		},
		getChartData : function(nfid,treeLoad,isSeperateApp){
			var _url =  contextPath+"/rest/MilestoneViewService/getMilestoneProjectStatus?nfid="+nfid,_params = {},_this = this,_url1 = contextPath+"/rest/MilestoneViewService/getIRMSIssueStatus?nfid="+nfid,_nfID = nfid;
			this.sendXMLHttpRequest(_url1,"GET",_params,false,function(data){
				if(data.result != undefined){	
					var chartData;
					chartData = [{
						label : "",
						data : data.result.Open,
						color : "#7F7F7F"
					},{
						label : "",
						data : data.result.Cancel,
						color : "#E66D05"
					},{
						label : "",
						data : data.result.Resolved,
						color : "#0e8412"
					}];
					$('.chartFooter').not('.small').find('span.open span').text(_this.isEmpty(data.result.Open));
					$('.chartFooter').not('.small').find('span.cancel span').text(_this.isEmpty(data.result.Cancel));
					$('.chartFooter').not('.small').find('span.resolved span').text(_this.isEmpty(data.result.Resolved));
					var _total = 0;
					_total = _total+parseInt(_this.isEmpty(data.result.Open))+parseInt(_this.isEmpty(data.result.Cancel))+parseInt(_this.isEmpty(data.result.Resolved));
					$('.chartBody').find('span.totalMs1').text(_total);
					$.plot('#placeholder2', chartData, {
						series: {
							pie: {
								innerRadius: 0.4,
								show: true,
								radius: 1,
								stroke: { 
									width: 0.3
								},
								label: {
									show: true,
									radius: 0.7,
									formatter: function(label,series){
										return "<div style='font-size:8pt; text-align:center; padding:2px; margin:-10px;color:white;'>"+ Math.round(series.percent) + "%</div>";
									},
									background: {
										opacity: 0
									}
								},
								background : {
									color : "gray"
								}
							}
						},
						legend: {
							show: false
						}
					});
					if($.isEmptyObject(data.result)){
						$('#displayIssues').hide();
					} else {
						$('#displayIssues').show();
						$('#displayIssues').find('iframe').attr('src',data.irmsURL+'?nfid='+_nfID);
					}
				} else {
					$.plot('#placeholder', [{
						label : "",
						data : 0,
						color : "#0e8412"
					},{
						label : "",
						data : 0,
						color : "#7F7F7F"
					},{
						label : "",
						data : 0,
						color : "#E66D05"
					}], {
						series: {
							pie: {
								innerRadius: 0.4,
								show: true,
								radius: 1,
								stroke: { 
									width: 0.3
								},
								label: {
									show: true,
									radius: 0.7,
									formatter: function(label,series){
										return "<div style='font-size:8pt; text-align:center; padding:2px; margin:-10px;color:white;'>"+ series.percent.toFixed(1) + "</div>";
									},
									background: {
										opacity: 0
									}
								},
								background : {
									color : "gray"
								}
							}
						},
						legend: {
							show: false
						}
					});
					$('#displayIssues').hide();
				}
			});
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(data){
				if(typeof treeLoad == "undefined" || treeLoad == "null" || treeLoad == "" || treeLoad == null || treeLoad == true || treeLoad == "true"){
					if(_this.uuiflag == "null" || _this.uuiflag == "false"){
						if(typeof isSeperateApp == "undefined"){
							//_this.loadTree(data,nfId);
						}
					} 
				}
				if(data.result != undefined){	
					actual = parseInt(data.result.Actual);
					excepted = parseInt(data.result.Excepted);
					var chartData;
					chartData = [{
						label : "",
						data : data.result.Completed,
						color : "#0e8412"
					},{
						label : "",
						data : data.result.NotStarted,
						color : "#7F7F7F"
					},{
						label : "",
						data : data.result.FallOut,
						color : "#E66D05"
					},{
						label : "",
						data : data.result.InProgress,
						color : "#20487B"
					},{
						label : "",
						data : data.result.Missed,
						color : "#F60307"
					}];
					$('.chartFooter').not('.small').find('span.complete span').text(_this.isEmpty(data.result.Completed));
					$('.chartFooter').not('.small').find('span.notstart span').text(_this.isEmpty(data.result.NotStarted));
					$('.chartFooter').not('.small').find('span.fall-out span').text(_this.isEmpty(data.result.FallOut));
					$('.chartFooter').not('.small').find('span.in-prog span').text(_this.isEmpty(data.result.InProgress));
					$('.chartFooter').not('.small').find('span.jeop span').text(_this.isEmpty(data.result.Missed));
					var _total = 0;
					_total = _total+parseInt(_this.isEmpty(data.result.Completed))+parseInt(_this.isEmpty(data.result.NotStarted))+parseInt(_this.isEmpty(data.result.FallOut))+parseInt(_this.isEmpty(data.result.InProgress))+parseInt(_this.isEmpty(data.result.Missed));
					$('.chartBody').find('span.totalMs').text(_total);
					$.plot('#placeholder', chartData, {
						series: {
							pie: {
								innerRadius: 0.4,
								show: true,
								radius: 1,
								stroke: { 
									width: 0.3
								},
								label: {
									show: true,
									radius: 0.7,
									formatter: function(label,series){
										return "<div style='font-size:8pt; text-align:center; padding:2px; margin:-10px;color:white;'>"+ Math.round(series.percent) + "</div>";
									},
									background: {
										opacity: 0
									}
								},
								background : {
									color : "gray"
								}
							}
						},
						legend: {
							show: false
						}
					});
					_this.setBarChart(data);
				} else {
					$.plot('#placeholder', [{
						label : "",
						data : 0,
						color : "#0e8412"
					},{
						label : "",
						data : 0,
						color : "#7F7F7F"
					},{
						label : "",
						data : 0,
						color : "#E66D05"
					},{
						label : "",
						data : 0,
						color : "#20487B"
					},{
						label : "",
						data : 0,
						color : "#F60307"
					}], {
						series: {
							pie: {
								innerRadius: 0.4,
								show: true,
								radius: 1,
								stroke: { 
									width: 0.3
								},
								label: {
									show: true,
									radius: 0.7,
									formatter: function(label,series){
										return "<div style='font-size:8pt; text-align:center; padding:2px; margin:-10px;color:white;'>"+ series.percent.toFixed(1) + "</div>";
									},
									background: {
										opacity: 0
									}
								},
								background : {
									color : "gray"
								}
							}
						},
						legend: {
							show: false
						}
					});
				}		
				$('.loadinContainer').parent('div').hide();
				$('.loadinContainer').parent('div').next('div').show();
				$('.chartHeader').find('ul li.close').unbind('click').bind('click',function(){
					$(this).closest('.chart').hide();
				});
				_this.hideLoading();
			});
			//this.getTempData(nfid);
		},
		getTempData : function(nfId){
			var _url =  contextPath+"/rest/ChartViewService/getChartData?nfid="+nfId,_this = this;
			this.sendXMLHttpRequest(_url,"GET",{},false,function(data){				
				_this.constructJSON(data);
			},function(){
				this.showMessage("Problem in processing your request! Please try again later","failure");
			});
		},
		constructJSON : function(data){
			var _this = this;
			if(typeof data != "undefined" && typeof data.result != "undefined"){
				if(data.result.length > 0){
					$.each(data.result,function(index,value){
						var _jsonArray = [];
						switch(index){
							case 0:
							case 1:
								if(data.result[index].length > 0){
									$.each(data.result[index],function(index1,value1){
										var _jsonObj = {};
										_jsonObj.type = "stackedBar";
										_jsonObj.indexLabel = "{y}";
										_jsonObj.indexLabelPlacement = "inside";
										_jsonObj.indexLabelOrientation = "horizontal";
										_jsonObj.indexLabelFontColor = "white";
										_jsonObj.indexLabelFontSize = 11;
										_jsonObj.showInLegend = false;
										switch(index1){
											case 0:
												var _dataResult = data.result[index][0];
												_jsonObj.name = "Construction";
												_jsonObj.color = "#6699FF";
												_jsonObj.dataPoints = [{y: _dataResult.RoomNotReady, label: "Room Not Ready"  },{y: _dataResult.PendingCCR, label: "Pending CCR"  },{y: _dataResult.PermitPending, label: "Permit Pending"  },{y: _dataResult.R4, label: "R4"  }];
												break;
											case 1:
												var _dataResult = data.result[index][1];
												_jsonObj.name = "Eng";
												_jsonObj.color = "#C34A2C";
												_jsonObj.dataPoints = [{y: _dataResult.RoomNotReady, label: "Room Not Ready"  },{y: _dataResult.PendingCCR, label: "Pending CCR"  },{y: _dataResult.PermitPending, label: "Permit Pending"  },{y: _dataResult.R4, label: "R4"  }];
												break;
											case 2:
												var _dataResult = data.result[index][2];
												_jsonObj.name = "Customer";
												_jsonObj.color = "#9DC209";
												_jsonObj.dataPoints = [{y: _dataResult.RoomNotReady, label: "Room Not Ready"  },{y: _dataResult.PendingCCR, label: "Pending CCR"  },{y: _dataResult.PermitPending, label: "Permit Pending"  },{y: _dataResult.R4, label: "R4"  }];
												break;
											default:
										}
										_jsonArray.push(_jsonObj);
									});
									_this.drawBarChart(_jsonArray,"chartContainer"+(index+1));
								}
								break;
							case 2:
								if(data.result[index].length > 0){
									$.each(data.result[index],function(index1,value1){
										var _jsonObj = {};
										_jsonObj.type = "stackedBar";
										_jsonObj.indexLabel = "{y}";
										_jsonObj.indexLabelPlacement = "inside";
										_jsonObj.indexLabelOrientation = "horizontal";
										_jsonObj.indexLabelFontColor = "white";
										_jsonObj.indexLabelFontSize = 11;
										_jsonObj.showInLegend = false;
										switch(index1){
											case 0:
												var _dataResult = data.result[index][0];
												_jsonObj.name = "FMC OSP";
												_jsonObj.color = "#6699FF";
												_jsonObj.dataPoints = [{y: _dataResult.R1, label: "R1"  },{y: _dataResult.R2, label: "R2"  },{y: _dataResult.R3, label: "R3"  },{y: _dataResult.R4, label: "R4"  }];
												break;
											case 1:
												var _dataResult = data.result[index][1];
												_jsonObj.name = "Hi Cap";
												_jsonObj.color = "#C34A2C";
												_jsonObj.dataPoints = [{y: _dataResult.R1, label: "R1"  },{y: _dataResult.R2, label: "R2"  },{y: _dataResult.R3, label: "R3"  },{y: _dataResult.R4, label: "R4"  }];
												break;
											case 2:
												var _dataResult = data.result[index][2];
												_jsonObj.name = "BROC";
												_jsonObj.color = "#9DC209";
												_jsonObj.dataPoints = [{y: _dataResult.R1, label: "R1"  },{y: _dataResult.R2, label: "R2"  },{y: _dataResult.R3, label: "R3"  },{y: _dataResult.R4, label: "R4"  }];
												break;
											default:
										}
										_jsonArray.push(_jsonObj);
									});
									_this.drawBarChart(_jsonArray,"chartContainer"+(index+1));
								}
								break;
							default:
						}
					});
				}
			}
		},
		drawBarChart : function(barData,placeholder){
			var chart = new CanvasJS.Chart(placeholder, {				
				height:118,
				width:230,
		        animationEnabled: false,
				axisX:{
					labelFontSize: 12,
					gridThickness: 0,
					lineThickness:0,
					labelFontFamily: 'Arial',
					labelFontColor:"black",
			        interval: 0,
			        tickLength: 0
				},
				axisY:{
					gridThickness: 0,
			        tickLength: 0,
			        lineThickness: 0,
			        valueFormatString: " ",
			        labelFontColor:"black",
			        labelFontSize: 10
				},
				toolTip: {
					enabled: false
				},
				data: barData
			});
			chart.render();
		},
		setBarChart : function(data){
			data.result.NotStarted = 0;
			data.result.FallOut = 0;
			data.result.InProgress = 0;
			var _total = 0,_notstartedpercentage = 0,_inprogresspercentage = 0,_falloutpercentage = 0;
			_total = _total+parseInt(this.isEmpty(data.result.NotStarted))+parseInt(this.isEmpty(data.result.FallOut))+parseInt(this.isEmpty(data.result.InProgress));
			$('.chartBody').find('span.totalMsJeop').text(_total);
			if(parseInt(this.isEmpty(data.result.NotStarted))>0){
				_notstartedpercentage = Math.round((parseInt(this.isEmpty(data.result.NotStarted))/_total)*100);
				if(_notstartedpercentage > 0){
					$('.barContainer').find('.notStarted-jeop').css("width",_notstartedpercentage+"%").parent('div').next('div').text(_notstartedpercentage+'%');
				}
			}
			if(parseInt(this.isEmpty(data.result.FallOut))>0){
				_falloutpercentage = Math.round((parseInt(this.isEmpty(data.result.FallOut))/_total)*100);
				if(_falloutpercentage > 0){
					$('.barContainer').find('.fallout-jeop').css("width",_falloutpercentage+"%").parent('div').next('div').text(_falloutpercentage+'%');
				}
			}
			if(parseInt(this.isEmpty(data.result.InProgress))>0){
				_inprogresspercentage = Math.round((parseInt(this.isEmpty(data.result.InProgress))/_total)*100);
				if(_inprogresspercentage > 0){
					$('.barContainer').find('.inprogress-jeop').css("width",_inprogresspercentage+"%").parent('div').next('div').text(_inprogresspercentage+'%');
				}
			}
			$('.loadinContainer1').parent('div').hide();
			$('.loadinContainer').parent('div').hide();
			$('.loadinContainer').parent('div').next('div').show();
			$('.loadinContainer1').parent('div').next('div').show();
		},
		isEmpty : function(data){
			return (typeof data != "undefined" && data != null && data != "null" && data != "")?data:"0";
		},
		labelFormatter : function(label, series) {
			return "<div style='font-size:5pt; text-align:center; padding:2px; color:white;'>"+ Math.round(series.percent) + "%</div>";
		},
		getMileStoneData : function(type){
			this.startMileStoneLoader();
			
			var _url =  contextPath+"/rest/MilestoneViewService/getMilestoneView",
			_params = {
				"nfid":this.nfid,
				"milestoneName":this.milestoneName,
				"milestoneType" : this.milestoneType,
				"startdate":this.startdate,
				"enddate":this.enddate,
				"duedate":this.duedate,
				"duration":this.duration,
				"milestonestatus":this.milestonestatus,
				"taskId":this.taskId,
				"assignedto":this.assignedto,
				"revisedEndDate":this.revisedEndDate
			},_this = this;
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(data){
				_this.buildHTML(data,type);
				if(_this.filterboolean){
					_this.expandAll();
				}
				_this.stopMileStoneLoader();
				if(typeof _this.uuiflag != "undefined" && _this.uuiflag != "" && _this.uuiflag != "null" && _this.uuiflag!=null && _this.uuiflag == "true"){
					_this.setParentHeight1(true);
				}
			},function(){
				_this.stopMileStoneLoader();
				if(typeof _this.uuiflag != "undefined" && _this.uuiflag != "" && _this.uuiflag != "null" && _this.uuiflag!=null && _this.uuiflag == "true"){
					_this.setParentHeight1(true);
				}
			});
			this.hideLoading();
		},
		showLoader : function(){
			$('.milestones').hide();
			$('.modalLayer').show();
		},
		hideLoader : function(){
			$('.milestones').show();
			$('.modalLayer').hide();
		},
		buildHTML : function(data,type){
			console.log("milestone json data -- > "+data);
			if(typeof data.result!= "undefined"){ 
				var _html = this.formHTMLElements(data.result,type);
				if(typeof type != "undefined" && type == "cip"){
					if(typeof this.cipMilestoneTable === 'object'){
						this.cipMilestoneTable.fnDestroy();
					}
					$('.milestonesCip').find('table tbody').html(_html);
					this.loadMileStoneDataTable();
				} else {
					$('.milestones .row.main,.milestones .row.submain,.milestones .row.sub').remove();
					$('.milestones').append(_html);
				}
			}else{
				if(typeof type != "undefined" && type == "cip"){
					if(typeof this.cipMilestoneTable === 'object'){
						this.cipMilestoneTable.fnDestroy();
					}
					$('.milestonesCip').find('table tbody').html('<tr><td colspan="6" style="align:center">No Data Available</div></div>');
					this.loadMileStoneDataTable();
				} else {
					$('.milestoneFrame').find('.empty').html('<div style="display:block;"><div style="width:100%;display:block;text-align:center;color:red;">No Data Available</div></div>');
				}
			}
			this.hideLoader();
		},
		loadMileStoneDataTable : function(data){
			this.cipMilestoneTable = $('#cipMilestoneTable').dataTable({
				"bDestroy":true,
				"bPaginate" : false,
				"bSort" : false,
				"bFilter" : false,
				"bInfo" : false,
				"bLengthChange" : false,
				"sScrollY" : "330px",
				"bScrollCollapse" : true
			});
		},
		formHTMLElements : function(data,type){
			var _this = this,_html = '';
			if(typeof data != "undefined"){
				if(typeof type != "undefined" && type == "cip"){
					_html += _this.formCIPChildElements(data,true);
				} else {
					_html += _this.formChildElements(data,true);
				}
			}
			return _html;
		},
		getAggregateMilestone : function(nfid){
			var _url =  contextPath+"/rest/MilestoneViewService/getAggregateMilestoneDataByNFID?nfid="+nfid,_params = {},_this = this;
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(data){
				var _html = '';
				$.each(data.results,function(i1,val1){
					var _actualCompleteDate = (typeof val1.ACTUAL_END_TIME != "undefined" && val1.ACTUAL_END_TIME!= "" && val1.ACTUAL_END_TIME != "null" && val1.ACTUAL_END_TIME!=null)?val1.ACTUAL_END_TIME:"";
					var _revisedTargetEndDate = (typeof val1.REVISED_TARGET_END_TIME != "undefined" && val1.REVISED_TARGET_END_TIME!= "" && val1.REVISED_TARGET_END_TIME != "null" && val1.REVISED_TARGET_END_TIME!=null)?val1.REVISED_TARGET_END_TIME:"";
					_html += '<div class="row main level0">';
					_html += '<div class="col-md-1 labelFont imageColumn"><i class="'+_this.getStatusIcon(val1.STATUS)+'"></i></div>';
					_html += '<div class="col-md-1 labelFont titleColumn"><span class="title" title="'+_this.isEmptyValue(val1.nf_domain_name)+'">'+_this.isEmptyValue(val1.nf_domain_name)+'</span></div>';
					_html += '<div class="col-md-1 extColumn">CCR</div>';
					_html += '<div class="col-md-1 dateColumn1">'+_this.isEmptyValue(val1.TARGET_END_TIME)+'</div>';
					_html += '<div class="col-md-1 dateColumn1">'+_revisedTargetEndDate+'</div>';
					_html += '<div class="col-md-1 dateColumn">'+_actualCompleteDate+'</div>';
					_html += '<div class="col-md-1 dateColumn">'+_this.isEmptyValue(val1.COUNT)+'</div>';
					_html += '</div>';
				});
				$('.milestones').append(_html);
			});
		},
		formCIPChildElements : function(data,isHighLevel){
			var _html = '',_this = this; 
			$.each(data,function(i1,val1){
				var _iconHtml = '',parentLevel0 = (val1.name.split(" ").length > 0)?val1.name.split(" ").join("_").removeSpecialChars():val1.name;
				_iconHtml = ((typeof val1.child!= "undefined" && val1.child.length>0) || (typeof val1.taskobj != "undefined" && val1.taskobj.length > 0))?'<i class="arrowRight"></i>':'';
				//console.log("inside for cip elements------>");
				var trIcon = _this.getStatusIcon(_this.checkOptional(val1.child,val1.status));
				//console.log("inside for cip elements" + trIcon);
				if(trIcon == 'notready'){
					_html += '<tr style = "color:gray">';
				}
				else{
				_html += '<tr>';
				}
				_html += '<td><i class="'+_this.getStatusIcon(_this.checkOptional(val1.child,val1.status))+'"></i></td>';
				
				_html += '<td><span class="title" title="'+val1.definition+'">'+val1.name+'</span></td>';
				//_html += '<td>CCR</td>';
				
				if(trIcon == 'notready'){
					_html += '<td>N/A</td>';
				}
				else{
					_html += '<td>'+val1.targetenddate+'</td>';
				}
				if(trIcon == 'notready'){
					_html += '<td>N/A</td>';
				}
				else{
					_html += '<td>'+val1.reviseddate+'</td>';
				}
				if(val1.unactualized != "undefined" && val1.unactualized !="" && val1.actualenddate !="undefined" && val1.actualenddate == "" )
					{
					var complDate = val1.unactualized +' ' + 'Un-actualized';
					actunactCompDate = val1.unactualized;
					_html += '<td style = "color:gray">'+complDate+'</td>';
					}
				else
					{
				_html += '<td>'+val1.actualenddate+'</td>';
					}
				
				if(typeof val1.actionperformed != "undefined" )
					{
					
					var milestoneHistory = val1.actionperformed;
					
					var mileActUser = milestoneHistory.split(",");
					
					//var time = val1.lastmodifiedtime.split(" ");
					
					
					//_html += '<td>'+mileActUser[0] +"by:" + mileActUser[1] +", "+time[0] + ", " +time[1]+" " +time[2]+" EST"+'</td>';
					_html += '<td>'+mileActUser[0] +"by:" + mileActUser[1] +", "+ mileActUser[2]+" EST"+'</td>';
					}
				else {
					_html += '<td></td>';
				}
				
				_html += '</tr>';
				
			});
			return _html;
		},
		formChildElements : function(data,isHighLevel){
			var _html = '',_this = this;
			$.each(data,function(i1,val1){
				var _iconHtml = '',parentLevel0 = (val1.name.split(" ").length > 0)?val1.name.split(" ").join("_").removeSpecialChars():val1.name;
				_iconHtml = ((typeof val1.child!= "undefined" && val1.child.length>0) || (typeof val1.taskobj != "undefined" && val1.taskobj.length > 0))?'<i class="arrowRight"></i>':'';
				_html += '<div class="row main level0">';
				_html += '<div class="col-md-1 imageColumn">'+_iconHtml+'</div>';
				_html += '<div class="col-md-1 labelFont imageColumn"><i class="'+_this.getStatusIcon(_this.checkOptional(val1.child,val1.status))+'"></i></div>';
				_html += '<div class="col-md-1 labelFont titleColumn"><span class="title">'+val1.name+'</span></div>';
				_html += '<div class="col-md-1 dateColumn1">'+val1.targetenddate+'</div>';
				_html += '<div class="col-md-1 dateColumn">'+val1.actualstartdate+'</div>';
				_html += '<div class="col-md-1 dateColumn">'+val1.actualenddate+'</div>';
				_html += '<div class="col-md-1 dateColumn">'+val1.duration+'</div>';
				_html += '<div class="col-md-1 dateColumn"></div>';
				_html += '<div class="col-md-1 extColumn"></div>';
				_html += '</div>';
				if(typeof val1.taskobj != "undefined" && val1.taskobj.length > 0){
					$.each(val1.taskobj,function(t1,tval1){
						var _assignedTo = (typeof tval1.assignedTo != "undefined")?tval1.assignedTo:"N/A";
						_html += '<div class="row sub level1 '+parentLevel0+'" style="display:none;">';
						_html += '<div class="col-md-1 imageColumn"></div>';
						_html += '<div class="col-md-1 labelFont imageColumn"></div>';
						_html += '<div class="col-md-1 titleColumn"><span class="title">'+tval1.eventname+'</span></div>';
						_html += '<div class="col-md-1 dateColumn1"></div>';
						_html += '<div class="col-md-1 dateColumn">'+tval1.actualstartdate+'</div>';
						_html += '<div class="col-md-1 dateColumn">'+tval1.actualenddate+'</div>';
						_html += '<div class="col-md-1 dateColumn">'+tval1.duration+'</div>';
						 /*_html += '<div class="col-md-1 dateColumn"><a href="javascript:void(0);">'+tval1.taskid+'</a></div>';*/
						_html += '<div class="col-md-1 dateColumn"><b>'+tval1.taskid+'</b></div>';
						_html += '<div class="col-md-1 extColumn" title="'+_assignedTo+'">'+_assignedTo+'</div>';
						_html += '</div>';
					});
				}
				if(typeof val1.child != "undefined" && val1.child.length > 0){
					$.each(val1.child,function(i2,val2){
						var _class1 = '',_iconHtml = '',taskObj = [],parentLevel1 = (val2.name.split(" ").length > 0)?val2.name.split(" ").join("_").removeSpecialChars():val2.name;;
						_class1 = ((typeof val2.child!= "undefined" && val2.child.length>0) || (typeof val2.taskobj != "undefined" && val2.taskobj.length > 0))?"submain":"sub";
						_iconHtml = ((typeof val2.child!= "undefined" && val2.child.length>0) || (typeof val2.taskobj != "undefined" && val2.taskobj.length > 0))?'<i class="arrowRight"></i>':'';
						if(typeof val2.taskobj != "undefined" && val2.taskobj.length > 0){
							taskObj = val2.taskobj;
						}
						_html += '<div class="row '+_class1+' level1 '+parentLevel0+'" style="display:none;">';
						_html += '<div class="col-md-1 imageColumn">'+_iconHtml+'</div>';
						_html += '<div class="col-md-1 labelFont imageColumn"><i class="'+_this.getStatusIcon(_this.checkOptional(val1.child,val2.status,val2.name))+'"></i></div>';
						_html += '<div class="col-md-1 labelFont titleColumn"><span class="title">'+val2.name+'</span></div>';
						_html += '<div class="col-md-1 dateColumn1">'+val2.targetenddate+'</div>';
						_html += '<div class="col-md-1 dateColumn">'+val2.actualstartdate+'</div>';
						_html += '<div class="col-md-1 dateColumn">'+val2.actualenddate+'</div>';
						_html += '<div class="col-md-1 dateColumn">'+val2.duration+'</div>';
						_html += '<div class="col-md-1 dateColumn"></div>';
						_html += '<div class="col-md-1 extColumn"></div>';
						_html += '</div>';
						if(taskObj.length > 0){
							$.each(taskObj,function(t1,tval1){
								var _assignedTo = (typeof tval1.assignedTo != "undefined")?tval1.assignedTo:"N/A";
								_html += '<div class="row sub level2 '+parentLevel0+' '+parentLevel1+'" style="display:none;">';
								_html += '<div class="col-md-1 imageColumn"></div>';
								_html += '<div class="col-md-1 labelFont imageColumn"></div>';
								_html += '<div class="col-md-1 titleColumn"><span class="title">'+tval1.eventname+'</span></div>';
								_html += '<div class="col-md-1 dateColumn1"></div>';
								_html += '<div class="col-md-1 dateColumn">'+tval1.actualstartdate+'</div>';
								_html += '<div class="col-md-1 dateColumn">'+tval1.actualenddate+'</div>';
								_html += '<div class="col-md-1 dateColumn">'+tval1.duration+'</div>';
								/*_html += '<div class="col-md-1 dateColumn"><a href="javascript:void(0);">'+tval1.taskid+'</a></div>';*/
								_html += '<div class="col-md-1 dateColumn"><b>'+tval1.taskid+'</b></div>';
								_html += '<div class="col-md-1 extColumn" title="'+_assignedTo+'">'+_assignedTo+'</div>';
								_html += '</div>';
							});
						}
						if(typeof val2.child != "undefined" && val2.child.length > 0){
							$.each(val2.child,function(i3,val3){
								var _class2 = '',_iconHtml = '',taskObj = [],parentLevel2 = (val3.name.split(" ").length > 0)?val3.name.split(" ").join("_").removeSpecialChars():val3.name;
								_class2 = ((typeof val3.child!= "undefined" && val3.child.length>0) || (typeof val3.taskobj!= "undefined" && val3.taskobj.length>0))?"submain":"sub";
								_iconHtml = ((typeof val3.child!= "undefined" && val3.child.length>0) || (typeof val3.taskobj!= "undefined" && val3.taskobj.length>0))?'<i class="arrowRight"></i>':'';
								if(typeof val3.taskobj != "undefined" && val3.taskobj.length > 0){
									taskObj = val3.taskobj;
								}
								_html += '<div class="row '+_class2+' level2 '+parentLevel0+' '+parentLevel1+'" style="display:none;">';
								_html += '<div class="col-md-1 imageColumn">'+_iconHtml+'</div>';
								_html += '<div class="col-md-1 labelFont imageColumn"><i class="'+_this.getStatusIcon(val3.status)+'"></i></div>';
								_html += '<div class="col-md-1 labelFont titleColumn"><span class="title">'+val3.name+'</span></div>';
								_html += '<div class="col-md-1 dateColumn1">'+val3.targetenddate+'</div>';
								_html += '<div class="col-md-1 dateColumn">'+val3.actualstartdate+'</div>';
								_html += '<div class="col-md-1 dateColumn">'+val3.actualenddate+'</div>';
								_html += '<div class="col-md-1 dateColumn">'+val3.duration+'</div>';
								_html += '<div class="col-md-1 dateColumn"></div>';
								_html += '<div class="col-md-1 extColumn"></div>';
								_html += '</div>';
								if(taskObj.length > 0){
									$.each(taskObj,function(t1,tval1){
										var _assignedTo = (typeof tval1.assignedTo != "undefined")?tval1.assignedTo:"N/A";
										_html += '<div class="row sub level3 '+parentLevel0+' '+parentLevel1+' '+parentLevel2+'" style="display:none;">';
										_html += '<div class="col-md-1 imageColumn"></div>';
										_html += '<div class="col-md-1 labelFont imageColumn"></div>';
										_html += '<div class="col-md-1 titleColumn"><span class="title">'+tval1.eventname+'</span></div>';
										_html += '<div class="col-md-1 dateColumn1"></div>';
										_html += '<div class="col-md-1 dateColumn">'+tval1.actualstartdate+'</div>';
										_html += '<div class="col-md-1 dateColumn">'+tval1.actualenddate+'</div>';
										_html += '<div class="col-md-1 dateColumn">'+tval1.duration+'</div>';
										/*_html += '<div class="col-md-1 dateColumn"><a href="javascript:void(0);">'+tval1.taskid+'</a></div>';*/
										_html += '<div class="col-md-1 dateColumn"><b>'+tval1.taskid+'</b></div>';
										_html += '<div class="col-md-1 extColumn" title="'+_assignedTo+'">'+_assignedTo+'</div>';
										_html += '</div>';
									});
								}
								if(typeof val3.child != "undefined" && val3.child.length > 0){
									$.each(val3.child,function(i4,val4){
										var _class3 = '',_iconHtml = '',taskObj = [],parentLevel3 = (val4.name.split(" ").length > 0)?val4.name.split(" ").join("_").removeSpecialChars():val4.name;
										_class3 = ((typeof val4.child!= "undefined" && val4.child.length>0)||(typeof val4.taskobj != "undefined" && val4.taskobj.length > 0))?"submain":"sub";
										_iconHtml = ((typeof val4.child!= "undefined" && val4.child.length>0)||(typeof val4.taskobj != "undefined" && val4.taskobj.length > 0))?'<i class="arrowRight"></i>':'';
										if(typeof val4.taskobj != "undefined" && val4.taskobj.length > 0){
											taskObj = val4.taskobj;
										}
										_html += '<div class="row '+_class2+' level3 '+parentLevel0+' '+parentLevel1+' '+parentLevel2+'" style="display:none;">';
										_html += '<div class="col-md-1 imageColumn">'+_iconHtml+'</div>';
										_html += '<div class="col-md-1 labelFont imageColumn"><i class="'+_this.getStatusIcon(val4.status)+'"></i></div>';
										_html += '<div class="col-md-1 labelFont titleColumn"><span class="title">'+val4.name+'</span></div>';
										_html += '<div class="col-md-1 dateColumn1">'+val4.targetenddate+'</div>';
										_html += '<div class="col-md-1 dateColumn">'+val4.actualstartdate+'</div>';
										_html += '<div class="col-md-1 dateColumn">'+val4.actualenddate+'</div>';
										_html += '<div class="col-md-1 dateColumn">'+val4.duration+'</div>';
										_html += '<div class="col-md-1 dateColumn"></div>';
										_html += '<div class="col-md-1 extColumn"></div>';
										_html += '</div>';
										if(taskObj.length > 0){
											$.each(taskObj,function(t1,tval1){
												var _assignedTo = (typeof tval1.assignedTo != "undefined")?tval1.assignedTo:"N/A";
												_html += '<div class="row sub level4 '+parentLevel0+' '+parentLevel1+' '+parentLevel2+' '+parentLevel3+'" style="display:none;">';
												_html += '<div class="col-md-1 imageColumn"></div>';
												_html += '<div class="col-md-1 labelFont imageColumn"></div>';
												_html += '<div class="col-md-1 titleColumn"><span class="title">'+tval1.eventname+'</span></div>';
												_html += '<div class="col-md-1 dateColumn1"></div>';
												_html += '<div class="col-md-1 dateColumn">'+tval1.actualstartdate+'</div>';
												_html += '<div class="col-md-1 dateColumn">'+tval1.actualenddate+'</div>';
												_html += '<div class="col-md-1 dateColumn">'+tval1.duration+'</div>';
												/*_html += '<div class="col-md-1 dateColumn"><a href="javascript:void(0);">'+tval1.taskid+'</a></div>';*/
												_html += '<div class="col-md-1 dateColumn"><b>'+tval1.taskid+'</b></div>';
												_html += '<div class="col-md-1 extColumn" title="'+_assignedTo+'">'+_assignedTo+'</div>';
												_html += '</div>';
											});
										}
										if(typeof val4.child != "undefined" && val4.child.length > 0){
											$.each(val4.child,function(i5,val5){
												var _class4 = '',_iconHtml = '',taskObj = [],parentLevel4 = (val5.name.split(" ").length > 0)?val5.name.split(" ").join("_").removeSpecialChars():val5.name;
												_class4 = ((typeof val5.child!= "undefined" && val5.child.length>0) || (typeof val5.taskobj != "undefined" && val5.taskobj.length > 0))?'submain':'sub';
												_iconHtml = ((typeof val5.child!= "undefined" && val5.child.length>0) || (typeof val5.taskobj != "undefined" && val5.taskobj.length > 0))?'<i class="arrowRight"></i>':'';
												if(typeof val5.taskobj != "undefined" && val5.taskobj.length > 0){
													taskObj = val5.taskobj;
												}
												_html += '<div class="row '+_class2+' level4 '+parentLevel0+' '+parentLevel1+' '+parentLevel2+' '+parentLevel3+'" style="display:none;">';
												_html += '<div class="col-md-1 imageColumn">'+_iconHtml+'</div>';
												_html += '<div class="col-md-1 labelFont imageColumn"><i class="'+_this.getStatusIcon(val5.status)+'"></i></div>';
												_html += '<div class="col-md-1 labelFont titleColumn"><span class="title">'+val5.name+'</span></div>';
												_html += '<div class="col-md-1 dateColumn1">'+val5.targetenddate+'</div>';
												_html += '<div class="col-md-1 dateColumn">'+val5.actualstartdate+'</div>';
												_html += '<div class="col-md-1 dateColumn">'+val5.actualenddate+'</div>';
												_html += '<div class="col-md-1 dateColumn">'+val5.duration+'</div>';
												_html += '<div class="col-md-1 dateColumn"></div>';
												_html += '<div class="col-md-1 extColumn"></div>';
												_html += '</div>';
												if(taskObj.length > 0){
													$.each(taskObj,function(t1,tval1){
														var _assignedTo = (typeof tval1.assignedTo != "undefined")?tval1.assignedTo:"N/A";
														_html += '<div class="row sub level5 '+parentLevel0+' '+parentLevel1+' '+parentLevel2+' '+parentLevel3+' '+parentLevel4+'" style="display:none;">';
														_html += '<div class="col-md-1 imageColumn"></div>';
														_html += '<div class="col-md-1 labelFont imageColumn"></div>';
														_html += '<div class="col-md-1 titleColumn"><span class="title">'+tval1.eventname+'</span></div>';
														_html += '<div class="col-md-1 dateColumn1"></div>';
														_html += '<div class="col-md-1 dateColumn">'+tval1.actualstartdate+'</div>';
														_html += '<div class="col-md-1 dateColumn">'+tval1.actualenddate+'</div>';
														_html += '<div class="col-md-1 dateColumn">'+tval1.duration+'</div>';
														/*_html += '<div class="col-md-1 dateColumn"><a href="javascript:void(0);">'+tval1.taskid+'</a></div>';*/
														_html += '<div class="col-md-1 dateColumn"><b>'+tval1.taskid+'</b></div>';
														_html += '<div class="col-md-1 extColumn" title="'+_assignedTo+'">'+_assignedTo+'</div>';
														_html += '</div>';
													});
												}
											});
										}
									});
								}
							});
						}
					});
				}
			});
			return _html;
		},
		getStatusIcon : function(status){
			var icon = "";
			switch(status.toLowerCase()){
				case "completed":
					icon = "completed";
					break;
				case "inprogress":
					icon = "inprogress";
					break;
				case "missed":
					icon = "missed";
					break;
				case "jeopardy":
					icon = "missed";
					break;
				case "onhold":
					icon = "hold";
					break;
				case "fallout":
					icon = "attention";
					break;
				case "notstarted":
					icon = "notstarted";
					break;
				case "canceled":
					icon = "canceled_1";
					break;
				case "notready":
					icon = "notready";
					break;
				case "aborted":
					icon = "completed";
					break;	
				default :
			}
			return icon;
		},
		getProjectStatusIcon : function(status){
			var icon = "";
			switch(status.toLowerCase()){
				case "unknown":
					icon = "notstarted_1";
					break;
				case "notstarted":
					icon = "notstarted_1";
					break;
				case "inprogress":
					icon = "inprogress_1";
					break;
				case "complete":
					icon = "completed_1";
					break;
				case "canceled":
					icon = "canceled_1";
					break;
				case "missed":
					icon = "missed_1";
					break;
				case "fallout":
					icon = "fallout_1";
					break;
				case "jeopardy":
					icon = "missed_1";
					break;
				case "retired":
					icon = "fallout_1";
					break;
				case "created":
					icon = "created_1";
					break;
				case "closed":
					icon = "closed_1";
					break;
				case "issue":
					icon = "missed_1";
					break;
				case "released":
					icon = "released_1";
					break;
				case "revisionrequested":
					icon = "revision";
					break;
				default :
			}
			return icon;
		},
		checkOptional : function(child,status,name){
			if(typeof child != "undefined"){
				var _childLength = child.length,_cnt = 0;
				if(typeof name == "undefined"){
					$.each(child,function(index,value){
						if(value.status == "completed"){
							_cnt = _cnt+1;
						}
						if(value.name == "Opened Order" && value.status != "completed"){
							_cnt = _cnt+1;
						}
						if(value.name == "In Service" && value.status != "completed"){
							_cnt = _cnt+1;
						}
					});
					if(_childLength == _cnt){
						return "completed";
					} else {
						return status;
					}
				} else if(name == "In Service" && status != "completed"){
					$.each(child,function(index,value){
						if(value.status == "completed"){
							_cnt = _cnt+1;
						}
						if(value.name == "Opened Order" && value.status != "completed"){
							_cnt = _cnt+1;
						}
						if(value.name == "In Service" && value.status != "completed"){
							_cnt = _cnt+1;
						}
					});
					if(_childLength == _cnt){
						return "completed";
					} else {
						return status;
					}
				} else if(name == "Opened Order" && status != "completed"){
					return "notready";
				} else {
					return status;
				}
			} else {
				return status;
			}
			
		},
		attachEvents : function(){
			var _this = this;
			$('#summaryPage').on('click','.menuPanelInCase ul li.ExpandAll',function(){
				_this.expandAll();
				return false;
			});		
			$('#summaryPage').on('click','.menuPanelInCase ul li.CollapseAll',function(){
				_this.collapseAll();
				return false;
			});
			$('#summaryPage').on('click','.menuPanelInCase ul li.reloadWindow',function(){
				_this.milestonesboolean=false;
				_this.taskIdBoolean = false;
				_this.assignedtoBoolean = false;
				$('.milestones').find('.filter input').val('');
				$("#milestonestatus").val('');
				$("#milestonetype").prop('selectedIndex',0);
				_this.milestoneName = "";
				_this.milestoneType = "";
				_this.startdate =  "";
				_this.enddate = "";
				_this.duedate =  "";
				_this.milestonestatus = "";
				_this.revisedEndDate ="";
				if(_this.isCipProject == false){
					_this.getMileStoneData();
				} else {
					_this.getMileStoneData('cip');
				}
				return false;
			});			
			$("#milestoneName").blur(function(){
				if(_this.milestonesboolean || $(this).val().length>2){
					_this.milestonesboolean = true;
					_this.filtermilestones();
				}
				if(_this.milestonesboolean && $(this).val().length==0){
					_this.milestonesboolean = false;
					_this.filtermilestones();
				}
			});
			$("#taskid_filter").blur(function(){
				if(_this.taskIdBoolean || $(this).val().length>2){
					_this.taskIdBoolean = true;
					_this.filtermilestones();
				}
				if(_this.taskIdBoolean && $(this).val().length==0){
					_this.taskIdBoolean = false;
					_this.filtermilestones();
				}
			});
			$("#assignedto_filter").blur(function(){
				if(_this.assignedtoBoolean || $(this).val().length>2){
					_this.assignedtoBoolean = true;
					_this.filtermilestones();
				}
				if(_this.assignedtoBoolean && $(this).val().length==0){
					_this.assignedtoBoolean = false;
					_this.filtermilestones();
				}
			});
			$(".datepicker").datepicker({
				changeMonth: true,
				changeYear: true,
				onSelect: function(){
					_this.filtermilestones();
				}
			});
			$('#milestonetype').change(function(){
				_this.filtermilestones();
			});
			$("#milestonestatus").change(function(){
				_this.filtermilestones();
			});
			$('.refresh').click(function(){
				_this.filterboolean = false;
				_this.milestonesboolean=false;
				$('.filter').find('input').val('');
				$("#milestonestatus").val('');
				_this.milestoneName = "";
				_this.milestoneType = "";
				_this.startdate =  "";
				_this.enddate = "";
				_this.duedate =  "";
				_this.milestonestatus = "";
				_this.revisedEndDate ="";
				if(_this.isCipProject == false){
					_this.getMileStoneData();
				} else {
					_this.getMileStoneData('cip');
				}
			});
			$('.milestones').on('click','.arrowRight,.arrowDown', function (){
				var _levelClass = $(this).closest('div.row').attr('class'),_classSplitted = _levelClass.split(" ")[2],_level = parseInt(_classSplitted.charAt(_classSplitted.length-1)),_toShowup = _level+1,_toShowupClass = "level"+_toShowup;
				var _textClass = ($.trim($(this).closest('div.row').find('div.col-md-1:eq(2) .title').text()).split(" ").length>0)?$.trim($(this).closest('div.row').find('div.col-md-1:eq(2) .title').text()).split(" ").join("").removeSpecialChars():$.trim($(this).closest('div.row').find('div.col-md-1:eq(2) .title').text()).removeSpecialChars(),_text = '';
				if($(this).hasClass('arrowRight')){
					$(this).removeClass('arrowRight').addClass('arrowDown');
					$('.milestones').find('div.row.'+_textClass+'.'+_toShowupClass).show();
					if(typeof _this.uuiflag != "undefined" && _this.uuiflag != "" && _this.uuiflag != "null" && _this.uuiflag!=null && _this.uuiflag == "true"){
						/*console.log("expand");
						console.log(document.body.scrollHeight);
						$('html').css('height', document.body.scrollHeight);*/
						_this.setParentHeight1(true);
					}
				} else {
					$(this).removeClass('arrowDown').addClass('arrowRight');
					$('.milestones').find('div.row.'+_textClass).hide();
					if(typeof _this.uuiflag != "undefined" && _this.uuiflag != "" && _this.uuiflag != "null" && _this.uuiflag!=null && _this.uuiflag == "true"){
						/*console.log("collapse");
						console.log(document.body.scrollHeight);
						$('html').css('height', document.body.scrollHeight);*/
						_this.setParentHeight1(true);
					}
				}
			});	
			$('.getmilestones').on('click',function(){
				_this.searchMilestones();
			});
			// new UI
			$('#summaryPage').on('click','.menuPanelInCase ul li.reloadWindow1',function(){
				_this.searchMilestones();
				return false;
			});			
			$(".milestonename").find("#milestonename").blur(function(){
				_this.searchMilestones();
				return false;
			});
			$("#taskid").blur(function(){
				_this.searchMilestones();
				return false;
			});
			$("#assigneName").blur(function(){
				_this.searchMilestones();
				return false;
			});
			$(".datepicker.dates").datepicker({
				changeMonth: true,
				changeYear: true,
				onSelect: function(){
					_this.searchMilestones();
				}
			});
			$("#status").change(function(){
				_this.searchMilestones();
			});
			$('.refresh').click(function(){
				_this.filterboolean = false;
				_this.milestonesboolean=false;
				$('.filter').find('input').val('');
				$("#milestonestatus").val('');
				_this.milestoneName = "";
				_this.milestoneType = "";
				_this.startdate =  "";
				_this.enddate = "";
				_this.duedate =  "";
				_this.milestonestatus = "";
				_this.revisedEndDate ="";
				if(_this.isCipProject == false){
					_this.getMileStoneData();
				} else {
					_this.getMileStoneData('cip');
				}
			});
		},
		expandAll : function(){
			$('.milestones div.row.main,.milestones div.row.sub,.milestones div.row.submain').each(function(){
				if($(this).find('div:eq(0) i').hasClass('arrowRight')){
					$(this).find('div:eq(0) i').removeClass('arrowRight').addClass('arrowDown');
				}
			});
			$('.milestones').find('div.row').show();
			if(typeof this.uuiflag != "undefined" && this.uuiflag != "" && this.uuiflag != "null" && this.uuiflag!=null && this.uuiflag == "true"){
				/*console.log("expandall");
				console.log(document.body.scrollHeight);
				$('html').css('height', document.body.scrollHeight);*/
				console.log("test");
				this.setParentHeight1(true);
			}
		},
		setParentHeight : function(isMileStone){
			var height = (typeof isMileStone == "undefined")?document.body.scrollHeight:$('#summaryPage').outerHeight();
			//parent.postMessage(height+","+window.location.href,'*');
		},
		setParentHeight1 : function(isMileStone){
			var height = (typeof isMileStone == "undefined")?document.body.scrollHeight:$('#summaryPage').outerHeight();
			//parent.postMessage(height+","+window.location.href,'*');
		},
		collapseAll : function(){
			$('.milestones div.row.main,.milestones div.row.sub,.milestones div.row.submain').each(function(){
				if($(this).find('div:eq(0) i').hasClass('arrowDown')){
					$(this).find('div:eq(0) i').removeClass('arrowDown').addClass('arrowRight');
				}
			});
			$('.milestones div.row.sub,.milestones div.row.submain').hide();
			if(typeof this.uuiflag != "undefined" && this.uuiflag != "" && this.uuiflag != "null" && this.uuiflag!=null && this.uuiflag == "true"){
				/*console.log("collapseall");
				console.log(document.body.scrollHeight);
				$('html').css('height', document.body.scrollHeight);*/
				this.setParentHeight1(true);
			}
		}, 
		filtermilestones:function(){
			this.filterboolean = true;
			if(this.isCipProject == false){
				this.milestoneName = $("#milestoneName").val();
				this.milestoneType = $('#milestonetype').val();
				this.startdate =  $("#startdate").val();
				this.enddate =  $("#enddate").val();
				this.duedate =  $("#duedate").val();
				console.log($('#duedate').val());
				this.taskId = $('#taskid_filter').val();
				this.assignedto = $('#assignedto_filter').val();
				this.milestonestatus = $("#milestonestatus").val();
				this.revisedEndDate=$("#revscheduledDate").val();
				this.getMileStoneData();
			} else {
				this.milestoneName = $("#milestoneName").eq(0).val();
				this.milestoneType = $('#milestonetype').eq(0).val();
				this.startdate =  $("#startdate").eq(0).val();
				this.enddate =  $("#enddate").eq(0).val();
				this.duedate =  $("#duedate").eq(0).val();
				console.log($('#duedate').eq(0).val());
				console.log($('#duedate').length);
				this.taskId = $('#taskid_filter').eq(0).val();
				this.assignedto = $('#assignedto_filter').eq(0).val();
				this.milestonestatus = $("#milestonestatus").eq(0).val();
				this.revisedEndDate=$("#revscheduledDate").eq(0).val();
				this.getMileStoneData('cip');
			}
		},
		sendXMLHttpRequest : function(url,type,params,isNeedsLoading,callbackfunction,errorCallBackFunction){
			var _this = this;
			this.hideMessage();
			if(typeof isNeedsLoading != "undefined" && isNeedsLoading == true){
				this.showLoading();
			}
			try{
				$.ajax({
					type:type,
					url: url,  
					data:params,
					timeout: 90000,
					dataType: "json",
					cache:false,
					success: function(data){ 
						callbackfunction(data);
						if(typeof isNeedsLoading != "undefined" && isNeedsLoading == true){
							_this.hideLoading();
						}
					},
					error:function(){
						if(typeof errorCallBackFunction != "undefined"){
							errorCallBackFunction();
						} else {
							_this.showMessage("Error loading your request.. Please try again later");
							if(typeof isNeedsLoading != "undefined" && isNeedsLoading == true){
								_this.hideLoading();
							}
						}
					}
				});
			} catch(e){
				this.showMessage("Error loading your request.. Please try again later");
				if(typeof isNeedsLoading != "undefined" && isNeedsLoading == true){
					this.hideLoading();
				}
			}
		},
		showLoading : function(){
			$('#modal-one').show();
			$('#summaryPage').hide();
		},
		hideLoading : function(){
			$('#modal-one').hide();
			$('#summaryPage').show();
		},
		mdiResizer : function(me){		
			if(window.frameElement !=null){
				this.myWinName = $(window.frameElement.parentNode).attr("id");	
				var windowBodyHeight = 780;
				if (windowBodyHeight > 0) {
					var _jobsummaryWinHeight = windowBodyHeight + 60 + 'px',
					_jobsummaryFrameHeight = windowBodyHeight + 85 + 'px',
					_treeHeight = windowBodyHeight + 193+'px',
					_windowMdiHeight = windowBodyHeight + 220 + 'px',
					_jobDetailHeight = windowBodyHeight + 225 + 'px',
					_frameHeight = windowBodyHeight + 270 + 'px';
					$(window.frameElement).css("height", _jobsummaryWinHeight);
					parent.$("#" + this.myWinName).css("height", _jobsummaryFrameHeight);
					if(uuiflag=="false"){
						if(parseInt(parent.parent.$("#mdiCtrWindow").css("height")) < parseInt(_jobsummaryFrameHeight)){
							parent.parent.$("#mdiCtrWindow").css("height", _windowMdiHeight);
							parent.parent.$("#treedIV").css("height", _treeHeight);
							parent.parent.parent.$("#" + parent.parent.window.name).css("height", _jobDetailHeight);
							parent.parent.parent.parent.$("#"+parent.parent.parent.window.name).css("height", _frameHeight);
						}
					}
				}else{
					if(uuiflag=="false"){
						parent.parent.parent.parent.$("#"+parent.parent.parent.window.name).css("height", _frameHeight);
					}
				}
			}
		},
		childResizer : function(me, i) {
			var _bodyHeight = document['body'].offsetHeight + 30 + 'px',_WinHeight = document['body'].offsetHeight + 70 + 'px';
			if(parent!=undefined){
				parent.$('.childframeWin' + i).css("height", _bodyHeight);
				parent.$("#" + me).css("height", _WinHeight);
			}
		},
		setWindowTitle : function(){
			window.document.title = this.nfid;
		},
		isEmptyValue : function(val){
			return (typeof val != "undefined" && val != "" && val != "null" && val != null)?val:"NA";
		},
		startMileStoneLoader : function(){
			$('#summaryPage').find('div.milestones').hide();
			$('#summaryPage').find('div#milestone_loading').show();
		},
		stopMileStoneLoader : function(){
			$('#summaryPage').find('div#milestone_loading').hide();
			$('#summaryPage').find('div.milestones').show();
		},
		// Create NF Project
		getProjectTypes : function(){
			var _url =  contextPath+"/rest/NetworkFulfillmentService/getProjectTypes";
			var _this = this;
			this.sendXMLHttpRequest(_url,"GET",{},false,function(data){
				projectorderworktypes = data;
				var _projectType = '';
				_projectType += '<option selected="selected">--Select--</option>';
				$.each(projectorderworktypes.result,function(i,val){
					_projectType += '<option value="'+i+'">'+val.name+'</option>';
				});
				$('#projectType').html(_projectType);
				$('#modal-one').hide();
				$('#createNFPROJECT').show();
			},function(){
				$('#modal-one').hide();
			});
			$(document).on('change','#projectType',function(){
				_this.loadWorkandOrderTypes($.trim($(this).val()));
			});
			$('#duedate').datepicker({
				changeMonth: true,
				changeYear: true
			});
		},
		loadWorkandOrderTypes : function(val){
			var _orderType = '',_workType = '',_mainArray;
			if(typeof projectorderworktypes.result != "undefined" && projectorderworktypes.result.length > 0){
				_mainArray = projectorderworktypes.result[val];
				//Order Types
				if(_mainArray.orders.length > 0){
					$.each(_mainArray.orders,function(i,val){
						_orderType += '<option value="'+val.order_name+'">'+val.order_name+'</option>';
					});
				} else {
					_orderType += '<option value="">--Select--</option>';
				}
				//Work Types
				if(_mainArray.worktypes.length > 0){
					$.each(_mainArray.worktypes,function(i,val){
						_workType += '<option value="'+val.work_type_name+'">'+val.work_type_name+'</option>';
					});
				} else {
					_workType += '<option value="">--Select--</option>';
				}
			} else {
				_orderType += '<option value="">--Select--</option>';
				_workType += '<option value="">--Select--</option>';
			}
			$('#orderTypes').html(_orderType);
			$('#workTypes').html(_workType);
		},
		attachMenuEvents : function(nfid,userVzId){
			var _this = this;
			$('#vzuui-main-menu').on('click','ul li',function(){
				_this.showLoading();
				$('#vzuui-main-menu').find('ul li a').removeClass('active');
				$(this).find('a').addClass('active');
				var _href = $(this).find('a').attr('datahref');
				switch(_href){
					case "searchProject":
					case "createProject":
						$('#networkfulfillment').load(_href+".jsp");
						break;
					case "attachments":
						var _nfid = (typeof $(this).find('a').attr('nfid') != "undefined" && $(this).find('a').attr('nfid')!="")?$(this).find('a').attr('nfid'):nfid;
						$('#networkfulfillment').load(_href+".jsp?nfid="+_nfid+"&vzid="+userVzId);
						break;
					case "network":
						var _nfid = (typeof $(this).find('a').attr('nfid') != "undefined" && $(this).find('a').attr('nfid')!="")?$(this).find('a').attr('nfid'):nfid;
						$('#networkfulfillment').load(_href+".jsp?nfid="+_nfid);
						break;
					default: 
				}
			});
			$('.vzuui-user-info').on('click','#logout_btn',function(){
				window.location = contextPath+"/jsp/login.jsp";
			});
			$('#networkfulfillment').load("createProject.jsp?nfid="+nfid);
		},
		attachCreateNFProjectEvents : function(){
			_this = this;
			$('.savenfproject').on('click',function(){
				$('#modal-one').show();
				$('#createNFPROJECT').hide();
				//_this.projectType	=	projectorderworktypes.result[$("#projectType").val()];
				_this.projectType	= 	$("#projectType option:selected").text();
				_this.requestType	=	$("#requestType").val();
				_this.orderType		=	$("#orderTypes").val();
				_this.workType		=	$("#workTypes").val();
				_this.duedate		=	$("#duedate").val();
				_this.orderDesc		=	$("#orderDesc").val();
				_this.createNFProject();	
			});
		},
		createNFProject : function(){
			var _url =  contextPath+"/rest/NetworkFulfillmentService/getNfId",
			_params = {
				"project_type":this.projectType,
				"REQ_TYPE":this.requestType,
				"Order_type":this.orderType,
				"WORK_TYPE":this.workType,
				"Due_Date":this.duedate,
				"ORDER_DESC":this.orderDesc,
			},_this = this;
			this.duedate="";
			this.sendXMLHttpRequest(_url,"GET",_params,false,function(data){				
				_this.redirectToDetailspage(data);
			},function(){
				this.showMessage("Problem in processing your request! Please try again later","failure");
				$('#modal-one').hide();
				$('#createNFPROJECT').show();
			});
		},
		redirectToDetailspage : function(data){
			if(typeof data.response!= "undefined"){ 
				 if(!isNaN(data.response)){
					  $('a[datahref="network"]').attr('nfid',data.response);
					  $('a[datahref="network"]').closest('li').trigger('click');
				  }else{
					  this.showMessage(data.response,"failure");
					  $('#modal-one').hide();
					  $('#createNFPROJECT').show();
				  }
			}else{
				this.showMessage("Problem in processing your request! Please try again later","failure");
				$('#modal-one').hide();
				$('#createNFPROJECT').show();
			}
		},
		attachLoginEvents : function(contextPath){
			var _this = this;
			/*$('#loginFrm').validationEngine({
				promptPosition: 'bottomLeft'
			});*/
			$(document).on('click','#singleEnggLoginBtn',function(){
				window.location = contextPath+'/jsp/welcome.jsp?nfid=1178';
				/*$('#loginFrm').hide();
				var _vzid = $('#vzid').val().toUpperCase();
				$('#vzid').val(_vzid);
				$('body').css({'background':'none'});
				$('#modal-one').show();
				if($('#loginFrm').validationEngine('validate')){
					var params = {"VZID" : $('#vzid').val()};
					$('#loginFrm').submit();
				}*/
			});
		},
		showMessage : function(message,type){
			var _html = '';
			switch(type){
				case "success":
					_html += '<div class="vzuui-conf-message"><span class="vzuui-conf-message-success"><strong>Confirmation</strong> '+message+'</span></div>';
					break;
				case "failure":
					_html += '<div class="vzuui-error-message"><span class="vzuui-error-message-success"><strong>Error</strong> '+message+'</span></div>';
					break;
				case "info":
					_html += '<div class="vzuui-alert-message"><span class="vzuui-alert-message-success"><strong>Alert / Warning</strong> '+message+'</span></div>';
					break;
				default :
			}
			$('.vzuui-alertMsg_holder').html(_html);
			$('.vzuui-alertMsg_holder').show();
		},
		hideMessage : function(){
			$('.vzuui-alertMsg_holder').empty();
			$('.vzuui-alertMsg_holder').hide();
		},
		/* NF Tree */
		loadTree : function(data,nfId,isCommon){
			var _treeData,_html = '',_this = this;
			if(typeof data.result != "undefined" && typeof data.result!= "undefined" && data.result.hasOwnProperty('ParentNFID') && data.result.AssociatedNFID.length > 0){
				_treeData = data.result;
				var _status1 = ($.trim(_treeData.ParentStatus1).toLowerCase().split(" ").length>0)?$.trim(_treeData.ParentStatus1).toLowerCase().split(" ").join(""):$.trim(_treeData.ParentStatus1).toLowerCase(),_isCurrentParent = (nfId === _treeData.ParentNFID)?"current":"";
				_html += '<li class="Nfid '+_isCurrentParent+'" data-parent="true" data-jobid="'+_treeData.ParentJobID+'" data-nfid="'+_treeData.ParentNFID+'"><a href="javascript:;"><i class="'+_this.getStatusIcon(_status1)+'"></i>'+_treeData.ParentNFID+'</a><ul>';
				if(typeof _treeData.AssociatedNFID != "undefined" && _treeData.AssociatedNFID.length > 0){
					$.each(_treeData.AssociatedNFID,function(index,value){
						var _status2 = ($.trim(value.ChildStatus1).toLowerCase().split(" ").length>0)?$.trim(value.ChildStatus1).toLowerCase().split(" ").join(""):$.trim(value.ChildStatus1).toLowerCase(),_isCurrentChild = (nfId === value.ChildNFID)?"current":"";
						_html += '<li class="Nfid '+_isCurrentChild+'" data-parent="false" data-nfid="'+value.ChildNFID+'" data-jobid="'+value.ChildJobId+'"><a href="javascript:;"><i class="'+_this.getStatusIcon(_status2)+'"></i>'+value.ChildNFID+'</a></li>';
					});
					_html += '</ul></li>';
				}
				if(typeof isCommon == "undefined"){
					this.hideMileStone();
				}
			} else {
				_html += '<li class="Nfid current" data-parent="false" data-jobid="" data-nfid="'+nfId+'"><a href="javascript:;">'+nfId+'</a></li>';
			}
			$('#navigation').html(_html);
			$("#navigation").treeview({
		        persist: "location",
		        collapsed: false,
		        unique: true
		    });
			if(typeof isCommon == "undefined"){
				$("#navigation .Nfid").unbind('click').bind('click',this.attachSummaryLoadEvent);
			} else {
				$("#navigation .Nfid").unbind('click').bind('click',this.attachSummaryLoadCommonEvent);
			}
		},
		attachSummaryLoadCommonEvent : function(e){
			e.stopPropagation();
			var _nfId = $(this).data('nfid'),_jobid = $(this).data('jobid'),_isParent = $(this).data('parent');
			$("#navigation").find('.current').removeClass('current');
			$(this).addClass('current');
			$('#modal-one').show();
			$('#networkfulfillment').hide();
			$('#networkfulfillment').load('commonIncludes.jsp?nfid='+_nfId+"&treeLoad=false",function(){
				$('#modal-one').hide();
				$('#networkfulfillment').show();
				if(typeof _isParent != "undefined" && _isParent == true){
					//$('#milestoneFrame_Details').hide();
					//$('#milestoneFrame_Details').prev('h3').hide();
				}
			});
		},
		attachSummaryLoadEvent : function(e){
			e.stopPropagation();
			var _nfId = $(this).data('nfid'),_jobid = $(this).data('jobid'),_isParent = $(this).data('parent');
			$("#navigation").find('.current').removeClass('current');
			$(this).addClass('current');
			$('#modal-two').show();
			$('#summaryPage').hide();
			$('#summaryPage').load('accordion.jsp?nfid='+_nfId+"&treeLoad=false",function(){
				$('#modal-two').hide();
				$('#summaryPage').show();
				if(typeof _isParent != "undefined" && _isParent == true){
					$('#milestoneFrame_Details').hide();
					$('#milestoneFrame_Details').prev('h3').hide();
				}
			});
		},
		hideMileStone : function(){
			$('#milestoneFrame_Details').hide();
			$('#milestoneFrame_Details').prev('h3').hide();
		},
		/* Network View */
		getProjectStatus : function(nfId){
			var _url =  contextPath+"/rest/MilestoneViewService/getProjectStatus?nfid="+nfId,_this = this;
			this.sendXMLHttpRequest(_url,"GET",{},false,function(data){				
				_this.showDiagram(data);
			},function(){
				this.showMessage("Problem in processing your request! Please try again later","failure");
			});
		},
		showDiagram : function(data){
			var _statusArray = ["INPROGRESS","COMPLETED","NOTSTARTED","MISSED","N/A"],
			_statusToLower = (typeof data.status != "undefined" && data.status != "")?$.trim(data.status):"NOTSTARTED";
			if($.inArray(_statusToLower,_statusArray)!=-1){
				$('.diagramIconContainer2 .connector').attr('title','NFID : '+data.nfid);
				$('.diagramIconContainer2 .connector').attr('nfid',data.nfid);
				$('.diagramIconContainer2 .connector').css({'cursor':'pointer'}); 
				switch($.inArray(_statusToLower,_statusArray)){
					case 0:
						$('.diagramIconContainer2 .connector').css({'border':'2px solid #FBB53A'}); 
						break;
					case 1:
						$('.diagramIconContainer2 .connector').css({'border':'2px solid #22940C'});
						break;
					case 2:
						$('.diagramIconContainer2 .connector').css({'border':'2px solid #CACACA'});
						break;
					case 3:
						$('.diagramIconContainer2 .connector').css({'border':'2px solid red'});
						break;
					case 4:
						$('.diagramIconContainer2 .connector').css({'border':'2px solid black'});
						break;
					default :
				}
			}
			$('.diagramContainer').show();
			//this.bindDiagramEvents();
		},
		bindDiagramEvents : function(){
			$('.diagramContainer').on('click','.connector',function(){
				//window.location.href=$(this).data('href');
			});
		},
		initAttachments : function(nfid){
			var _this = this;
			this.loadDataTable();
			$('#modal-one').hide();
			$('#attachments').show();
			$('#hicapupload').validationEngine();
			$('.actionable').on('click','.vplus',function(){
				_this.showUploadForm();
			});
			$('#hicapUploadForm').on('click','.saveUploadAttachment',function(){
				if($('#hicapupload').validationEngine('validate')){ 
					var arr = $('#file').val().split("\\");
					var fileName = arr[arr.length-1];
					if(fileName.indexOf("/") >= 0){
						arr = fileName.split("/");
						fileName =arr[arr.length-1];
					}
					if(_this.isValidFileNameLength(fileName)){
						if(_this.isValidFileName(fileName)){
							_this.loadAjaxFormUpload(nfid);
						}else{
							_this.showMessage("File name can have only any of following characters [A-B],[a-z],[0-9],Periods, underscores and hyphens","failure");
						}
					} else{
						_this.showMessage("File name can not exceed 120 length","failure");
						return false;
					}
				} else { 
					return false; 
				}
			});
			$('#hicapUploadForm').on('click','.cancelUploadAttachment',function(){
				_this.hideMessage();
				$('#attachmentListData').show();
				$('#hicapUploadForm').hide();
			});
			$('.checkbox_files').live('click',function(){
				console.log($('.checkbox_files:checked').length);
				if($('.checkbox_files:checked').length > 0){
					if($('.vminus').hasClass('disabled')){
						$('.vminus').removeClass('disabled');
					}
				} else {
					if(!$('.vminus').hasClass('disabled')){
						$('.vminus').addClass('disabled');
					}
				}
			});
			$('.actionable').on('click','.vminus',function(e){
				if(!$('.vminus').hasClass('disabled')){
					if(confirm('Are you sure you want to delete?')){
						_this.deleteAttachments(_this);
					}
				} 
			});
			$('#file').live('change',function(){
				var _fileName = _this.extractFilename($(this).val());
				$('#originalFileName').val(_fileName);
			});
		},
		deleteAttachments : function(ref){
			this.hideMessage();
			var _deletedAttachments = [],_this = new SingleEnggApp();
			$('.checkbox_files:checked').each(function(){
				_deletedAttachments.push({"attachmentId":$(this).attr('id')});
			});
			$('#attachments').hide();
			$('#modal-one').show();
			var _url = contextPath+"/rest/file/fileDelete";
			try{
				$.ajax({
					type:"POST",
					url: _url,  
					data:JSON.stringify(_deletedAttachments),
					timeout: 90000,
					dataType: "json",
					contentType : "application/json",
					success: function(data){ 
						$('#modal-one').hide();
						$('#attachments').show();
						$('#hicapupload')[0].reset();
						if(!$('.vminus').hasClass('disabled')){
							$('.vminus').addClass('disabled');
						}
						ref.loadDataTable();
					},
					error:function(){
						ref.showMessage("Problem in processing your request! Please try again later","failure");
						$('#modal-one').hide();
						$('#attachments').show();
					}
				});
			} catch(e){
				ref.showMessage("Problem in processing your request! Please try again later","failure");
				$('#modal-one').hide();
				$('#attachments').show();
			}
		},
		loadDataTable : function(){
			if(typeof attachmentsGrid != "undefined" && attachmentsGrid != "") attachmentsGrid.fnDestroy();
			attachmentsGrid = $('#orderTable3').dataTable({
				"sAjaxDataProp": "RESULTS",	
				"bRetrieve": true,
				"sAjaxSource" : contextPath+"/rest/file/getList?nfid="+nfid,
				"aoColumns" : [ {"mData": "ATTACHMENT_ID","sWidth":"1%"  },
	                {"mData" : "FILE_NAME","sWidth":"34%" ,"defaultContent": "<i>N/A</i>"}, 
	                {"mData" : "FILE_DESCRIPTION","sWidth":"20%","defaultContent": "<i>N/A</i>" },
	                {"mData" : "UPLOADEDUSER_NAME","sWidth":"25%","defaultContent": "<i>N/A</i>" },
	                {"mData" : "ATTACHED_TIME","sWidth":"20%","defaultContent": "<i>N/A</i>" }],
				'dom' : '<<t>ip>',
				"ordering": true,
				"paging":   false,
				"info" : false,
				"fnRowCallback" : function(nRow,data,index){
					if(data["UPLOADED_BY"]===userVzId){
						$('td:eq(0)', nRow).html('<input type="checkbox" name="files" id="' + data["ATTACHMENT_ID"] + '" class="checkbox_files" />' );
					} else {
						$('td:eq(0)', nRow).html('');
					}
	  				$('td:eq(1)', nRow).html('<a href="'+contextPath+'-services/'+data["FILE_NAME"]+'" target="_blank">'+data["FILE_DISPLAY_NAME"]+'</a>');	  				
	  			}
			});
		},
		showUploadForm : function(){
			this.hideMessage();
			$('#attachmentListData').hide();
			$('#hicapUploadForm').show();
		},
		loadAjaxFormUpload : function(nfId){
			this.hideMessage();
			var finalPath,_this = this;
		//	$('#attachments').hide();
			$('#modal-one').show();
			finalPath = contextPath+"/rest/file/fileUpload?nfid="+nfId+"&fileType="+$.trim($('#attachment_type').val())+"&vzid="+userVzId;
			$('#hicapupload').ajaxForm({
				url:finalPath,
				headers: {
			        "X-Requested-With":"XMLHttpRequest"
			    },
			    contentType: 'application/json',
		        dataType:'json',
				success : function(data){
					$('#modal-one').hide();
					$('#attachments').show();
					_this.loadDataTable();
					if(data.result == 'Success'){
						if(data.isValidFileName == 'N'){
							_this.showMessage("File name can not exceed 120 length","failure");
						} else if(data.spaceFlag == 'Y'){
							$('#attachmentListData').show();
							$('#hicapUploadForm').hide();
							$('#hicapupload')[0].reset();
							_this.showMessage("File has been successfully attached! , SPACE replaced with UNDERSCORE","success");
						} else{
							$('#attachmentListData').show();
							$('#hicapUploadForm').hide();
							$('#hicapupload')[0].reset();
							_this.showMessage("File has been successfully attached!","success");
						}
					} else{
						if(data.isValidFileName == 'N'){
							_this.showMessage("File name can not exceed 120 length","failure");
						} else if(data.isFileAlreadyExist == 'Y'){
							_this.showMessage("File is already uploaded with this name, Please try with another name","failure");
						} else {
							_this.showMessage("File Not Uploaded","failure");
						}
					}
					$('.vminus').addClass('disabled');
				}
			});
			$('#hicapupload').submit();
		},
		extractFilename : function(s){ 
			return (typeof s==='string' && (s=s.match(/[^\\\/]+$/)) && s[0]) || '';
		},
		isValidFileNameLength : function(fileName){
			return (fileName.length <= 120);
		},
		isValidFileName : function(fileName){	
			var alphaExp  = /^[-0-9a-zA-Z -._]+$/;
			if(!fileName.match(alphaExp)){
				return false;
			}
			return true;
		},
		getJobId:function(){
			var _this = this;
			console.log(contextPath);
			console.log(nfid);
			var _url =  contextPath+"/rest/project/getNfJobId/"+nfid;
			$.ajax({
				type:'GET',
				url: _url,  
				timeout: 90000,
				dataType: "json",
				contentType : "application/json",
				cache:false,
				success: function(data){
					console.log(data);
					$("#jobid").val(data);
					_this.searchMilestones();
				},
				error:function(e){
					console.log(e);
				}
			});
			
		},
		getMilestoneViews : function(){
			var _url = contextPath+"/rest/MilestoneViewService/getMileStoneViews";
			var _html = '<option value="">--Please Select--</option>';
			this.sendXMLHttpRequest(_url,"GET",{},false,function(data){
				if(typeof data.results != "undefined" && data.results.length > 0){
					$.each(data.results,function(index,value){
						_html += '<option value="'+value.value+'">'+value.label+'</option>';
					});
				}
				$('#milestoneviewid').html(_html);
				
			},function(){
				$('#milestoneviewid').html(_html);
			});
			this.attachEvents();
		},
		searchMilestones : function(){
			var _params = $('#searchMilestone').serializeObject(),_contextPath = contextPath,_url = _contextPath+"/rest/MilestoneViewService/getMilestoneViewByJobID",_this = this;
			this.startMileStoneLoader();
			$.ajax({
				type:'POST',
				url: _url,  
				data:JSON.stringify(_params),
				timeout: 90000,
				dataType: "json",
				contentType : "application/json",
				cache:false,
				success: function(data){ 
					_this.buildHTML(data);
					if(_this.filterboolean){
						_this.expandAll();
					}
					_this.stopMileStoneLoader();
				},
				error:function(){
					if(typeof errorCallBackFunction != "undefined"){
						errorCallBackFunction();
					} else {
						_this.showMessage("Error loading your request.. Please try again later");
						if(typeof isNeedsLoading != "undefined" && isNeedsLoading == true){
							_this.hideLoading();
						}
					}
				}
			});
		},
		getVzidRoles : function(vzid){
			
			var _url = contextPath+"/rest/MilestoneViewService/getRolesForVZID?vzid="+vzid,_params = {},_this = this;
			var status='';
			
			//$("#cipMilestoneTable").delegate("tr", "click", function(e) {
			$("#cipMilestoneTable").click (function(e) {
				
				 var el = e.target; // DOM of the HTML element which was clicked
				 console.log("el.nodeName   --> " +el.nodeName);
				    if (el.nodeName == "TD") {
				        
				        el = $(el,this.rows).closest("tr");
				        var iCol = $(e.target,this.rows).closest("td");
				        iCol=$(iCol).index();
				        var row = $(e.target,this.rows).closest("tr");
				        row=$(row).index();
				        var rowId = row[0];
				        console.log("iCol  --> " + iCol +"row -- >"+ row );
				        
				         selectedValue=el.find('td:eq(' + iCol + ')');
				         selectedText = selectedValue.html();
				        console.log("cell value" + selectedValue.html() +"---" +selectedText );
				        /*if (iCol==0) {//When checkbox is clicked then restore row
				        	jQuery('#cipMilestoneTable').jqGrid('restoreRow',rowId);
				        	}*/
				    
				 milestoneName = el.find('td:eq(1)').text();
				 status = el.find('td:eq(0)').find("i").attr("class");
				 originalSchDate = el.find('td:eq(2)').text();
				 atualCompDate = el.find('td:eq(4)').text();
				 //console.log("milestone in JS " + milestoneName  + status);
				//alert("milestone in JS " + milestoneName  + status);
				   
				    }
				   
			var date = new Date();
		    var currentMonth = date.getMonth();
		    var currentDate = date.getDate();
		    var currentYear = date.getFullYear();
			$.ajax({
				type:'GET',
				url: _url,  
				data:JSON.stringify(_params),
				timeout: 90000,
				dataType: "json",
				contentType : "application/json",
				cache:false,
				success: function(data){ 
					
					console.log("response data " + data.response);
					console.log("milestoneName " + milestoneName);
					console.log("status " + status);
					if(data.response != "undefined" && data.response !="" && data.response == "TRUE" && status !='completed' && status !='notready'  && iCol == 2)
					{
					console.log("inside if ajax" + status);
					
					$('#revisedDate').datepicker({
						 minDate: new Date(currentYear, currentMonth, currentDate),
						 dateFormat: 'yy-mm-dd',
						 changeMonth: true,
							changeYear: true,
							beforeShowDay: function(date) {
								var day = date.getDay();
								return [(day != 0 && day != 6), ''];
							  }
						
					});
					$("#dialog ").find(".textDate").text(milestoneName);
					$("#dialog ").find(".reason").text("Select Reason");
					//$( "#dialog" ).dialog({title:"data",modal: true,autoOpen: false,width:400,height:300,button:false});
					$( "#dialog" ).dialog({title:"Enter in Revised Scheduled Date",modal: true,autoOpen: false,width:400,height:350,button:false});
					$( "#dialog" ).dialog( "open" );
					$("#milestonereason").val("");
					//$( "#dialog" ).dialog( "open" );
					}
					else if(data.response != "undefined" && data.response !="" && data.response == "TRUE" &&  status =='completed'  && iCol == 4 && selectedText.indexOf('Un-actualized') == -1)
						{
						$("#dialogCompleteDate ").find(".CompUnActualiseText").text("Are you sure want to unactualize this milestone?");
						$( "#dialogCompleteDate" ).dialog({title:"",modal: true,autoOpen: false,width:300,height:200,button:false});
						$( "#dialogCompleteDate" ).dialog( "open" );
						}
					else if(data.response != "undefined" && data.response !="" && data.response == "TRUE"  && iCol == 4 && selectedText.indexOf('Un-actualized') !== -1)
					{
						console.log("atualCompDate3" +atualCompDate);
						console.log("actunactCompDate" + actunactCompDate);
					$("#dialogReActualiseDate ").find(".CompDateReActualiseText").text("Are you sure you want to re-actualize this milestone with today's date?");
					$( "#dialogReActualiseDate" ).dialog({title:"",modal: true,autoOpen: false,width:300,height:200,button:false});
					$( "#dialogReActualiseDate" ).dialog( "open" );
					}
					else{
						console.log("inside else ajax");
					}
				}});
			});
		},
		isMilestoneRescheduled : function(projectId){
			console.log("isMilestoneRescheduled " + projectId);
			var _url = contextPath+"/rest/MilestoneViewService/getIsMilestoneRescheduled?projectId="+projectId,_params = {},_this = this;
			$.ajax({
				type:'GET',
				url: _url,  
				data:JSON.stringify(_params),
				timeout: 90000,
				dataType: "json",
				contentType : "application/json",
				cache:false,
				success: function(data){ 
					
					console.log("response data isMilestoneRescheduled " + data.results);
					var isScheduled = data.results;
					if(isScheduled != "undefined" && isScheduled !="" && isScheduled == "true")
						{
							$('#projectFrameDetails').find('.milestoneRescheduled').text("Yes");
						} else {
							$('#projectFrameDetails').find('.milestoneRescheduled').text("No");	
						}
					
				}});
		},
		isMilestoneRescheduledNfid : function(nfid){
			console.log("isMilestoneRescheduledNfid " + nfid);
			var _url = contextPath+"/rest/MilestoneViewService/getIsMilestoneRescheduledNfid?nfid="+nfid,_params = {},_this = this;
			$.ajax({
				type:'GET',
				url: _url,  
				data:JSON.stringify(_params),
				timeout: 90000,
				dataType: "json",
				contentType : "application/json",
				cache:false,
				success: function(data){ 
					
					console.log("response data isMilestoneRescheduledNfid " + data.results);
					var isScheduled = data.results;
					if(isScheduled != "undefined" && isScheduled !="" && isScheduled == "true")
						{
							$('#projectFrameDetails').find('.milestoneRescheduled').text("Yes");
						} else {
							$('#projectFrameDetails').find('.milestoneRescheduled').text("No");	
						}
					
				}});
		},
		getProjectId : function(nfid){
			console.log("getProjectId " + nfid);
			var _url = contextPath+"/rest/MilestoneViewService/getProjectId?nfid="+nfid,_params = {},_this = this;
			$.ajax({
				type:'GET',
				url: _url,  
				data:JSON.stringify(_params),
				timeout: 90000,
				dataType: "json",
				contentType : "application/json",
				cache:false,
				success: function(data){ 
					
					console.log("response data getProjectId " + data.results);
					 nfProjectId = data.results;
					console.log("get Project id for nfProjectId" + nfProjectId);
					
				}});
		},
		addMilestoneHistory : function(dataJsonAddNotes){
			console.log("inside add notes" +dataJsonAddNotes);
			 $.ajax({
					type: "POST",
					contentType: "application/json; charset=utf-8",
					url: contextPath+"/rest/RemarksService/addNotes",
					
				    data: dataJsonAddNotes,
					dataType: "json",
					success: function(response){
						if(response.statusMessage === "Success") {
							$("#successMessage").show();
						
							//fetchAllNotes();
							console.log("success message" + response);
							setTimeout(function(){
								$("#successMessage").hide();
							},5000);
						}else{
							$("#errorMessage").show();
							setTimeout(function(){
								$("#errorMessage").hide();
							},5000);
						}
						
					},
					error: function(response){
						
					}
				 });
		},
		invokeCCPService : function(dataJsonCCP){
			console.log("invokeCCPService" +dataJsonCCP);
			$.ajax({
				type: "POST",
				contentType: "application/json; charset=utf-8",
				url: contextPath+"/rest/milestones/ccpInvokeForActUnact",
				
			    data: dataJsonCCP,
				dataType: "json",
				success: function(response){
					if(response.statusCode == "0") {
						console.log("success message" + response);
					}else if(response.statusCode == "1")
						{
						console.log("CCP Failed");
						$("#dialogError ").find(".errorText").text(response.statusMessage);
						$( "#dialogError" ).dialog({title:"Error",modal: true,autoOpen: false,width:300,height:200,button:false});
						
						$( "#dialogError" ).dialog( "open" );
						}else{
							console.log("No CCP Call");
						}
					
				},
				error: function(response){
					
				}
			 });
			
		},
		updateMilestoneAction : function(dataJsonMilestone){
			console.log("updateMilestoneAction" +dataJsonMilestone);
			$.ajax({
				type: "POST",
				contentType: "application/json; charset=utf-8",
				url: contextPath+"/rest/milestones/updateMilestoneAction",
				
			    data: dataJsonMilestone,
				dataType: "json",
				success: function(response){
					if(response.statusCode == "0") {
						console.log("success message" + response);
					}else{
							console.log("No update");
						}
					
				},
				error: function(response){
					
				}
			 });
			
		},
		getMilestoneTaskData : function(nfid){
			console.log("getMilestoneTaskData----getProjectId " + nfid);
			var _url = contextPath+"/rest/MilestoneViewService/getMilestoneTaskData?nfid="+nfid,_params = {},_this = this;
			
			$.ajax({
				type:'GET',
				url: _url,  
				data:JSON.stringify(_params),
				timeout: 90000,
				dataType: "json",
				contentType : "application/json",
				cache:false,
				success: function(data){
					//if(data.results.length>0){
						//console.log("rdata.results.sizeee " + data.results.length);
					_this.formMilestoneTaskElements(data);
					
					console.log("response data getProjectId " + data.results);
					 nfProjectId = data.results;
					console.log("get Project id for nfProjectId" + nfProjectId);
					//}
					
				},
				error: function(response){
					
				}
			
			});
			
			
		},
		
		formMilestoneTaskElements : function(data){
			var _html = '',_this = this; 
			//$.each(data.results,function(i1,val1){
			//console.log("inside form milestone task elements" + data.results + val1.DOMAIN_NAME + val1.DOMAIN_STATUS + val1.TASK_NAMES_LIST);	
				
			
				/*_html += '<tr style="font-weight:bold">';
				_html += '<td><i class="'+_this.getStatusIcon(val1.DOMAIN_STATUS)+'"></i></td>';
				_html += '<td>'+val1.DOMAIN_NAME+'</td>';
				if(val1.DOMAIN_END_TIME != "" && val1.DOMAIN_END_TIME != "undefined"){
									_html += '<td>'+val1.DOMAIN_END_TIME+' EST</td>';
									}
									else
										{
										_html += '<td>'+val1.DOMAIN_END_TIME+'</td>';
										}
				val1 = data.results;*/
			$.each(data.results,function(i1,val1){
				
				//console.log("tasknamelist" +val1.TASK_NAMES_LIST.length + val1.TASK_NAMES_LIST.TASK_STATUS);
				if(val1.TASK_NAMES_LIST.length>=1)
				{
											$.each(val1.TASK_NAMES_LIST,function(i1,val2){
																								
												if(val2.TASK_STATUS !=null&&val2.TASK_STATUS != "undefined" && val2.TASK_STATUS !=""){
													var listIcon = _this.getStatusIcon(val2.TASK_STATUS);
													if(listIcon == "notready"){
														_html += '<tr style = "color:gray">';
													}else{
														_html += '<tr>';
													}
												
												
												_html += '<td><i class="'+_this.getStatusIcon(val2.TASK_STATUS)+'"></i></td>';
												_html += '<td style="text-indent:7px">'+val2.TASK_NAME+'</td>';
												
												var s = val2.TASK_END_TIME.split(' ');
												if(val2.TASK_END_TIME != "" && val2.TASK_END_TIME != "undefined"){
												console.log("formatted TASK_END_TIME" +  s[0] + s[1] +" --- " +val2.TASK_END_TIME);
												 var a1 = s[0].split('-');
												 var a2 = s[1].split(':');
												 var a3 = a2[2].split('.');
																						
												 if(a2[0] > 12){
												
													 _html += '<td >'+a1[1]+"/" + a1[2] +"/"+ a1[0]+ " " +a2[0]+":" + a2[1] +":"+ a3[0] +' PM EST'+'</td>';
												 }
												 else{
													 _html += '<td >'+a1[1]+"/" + a1[2] +"/"+ a1[0]+ " " +a2[0]+":" + a2[1] +":"+ a3[0] +' AM EST'+'</td>';
													 
												 }
												}
												else
													{
													_html += '<td></td>';
													}
												_html += '</tr>';
												}
										});
				}
											
												
												var domainIcon = _this.getStatusIcon(val1.DOMAIN_STATUS);
												if(domainIcon == "notready"){
												_html += '<tr style = "color:gray ; font-weight:bold">';
												}
												else{
													_html += '<tr style="font-weight:bold">';
												}
												_html += '<td><i class="'+_this.getStatusIcon(val1.DOMAIN_STATUS)+'"></i></td>';
												_html += '<td>'+val1.DOMAIN_NAME+'</td>';
												if(val1.DOMAIN_END_TIME != "" && val1.DOMAIN_END_TIME != "undefined"){
																	_html += '<td>'+val1.DOMAIN_END_TIME+' EST</td>';
																	}
																	else
																		{
																		_html += '<td>'+val1.DOMAIN_END_TIME+'</td>';
																		}
											});
												
			//});
			
			_this.loadMileStoneTaskDataTable();
			$('.milestonesTask').find('table tbody').html(_html);
		},
		loadMileStoneTaskDataTable : function(){
	
			this.cipMilestoneTable = $('#cipMilestoneTaskTable').dataTable({
				"bDestroy":true,
				"bPaginate" : false,
				"bSort" : false,
				"bFilter" : false,
				"bInfo" : false,
				"bLengthChange" : false,
				"scrollY":      400,
				"scrollCollapse": true,
				"paging":         false,
				"columnDefs": [
				               { "width": "10%", "targets": 0 }
				]
				});
			},
		initializeTabs : function(projectId,ccrId,actualNfId){
			var _url = contextPath+"/rest/NetworkFulfillmentService/getSmartJumpUrl?projectId="+projectId+'&ccrId='+ccrId+'&textNfId='+actualNfId,_nfid = nfid;
			var _html = '',_html1 = '',_this = this;
			this.sendXMLHttpRequest(_url,"GET",'',false,function(data){
				var _sortedArray = _this.getSortedTabs(data.tabDetails,'tabOrder');
				$.each(_sortedArray,function(index,value){
					var _class = (index === 0)?'active':'';
					if(typeof value.type != 'undefined' && value.type == 'E'){
						_html += '<li class="'+_class+'"><a href="decSummary.jsp?tabName='+value.tabName+'">'+value.tabName.toUpperCase()+'</a></li>';
					} else {
						_html += '<li class="'+_class+'"><a href="'+value.tabUrl+'">'+value.tabName.toUpperCase()+'</a></li>';
					}
				});
				if(typeof(Storage) !== "undefined") {
					sessionStorage.tabDetails = JSON.stringify(data);
				}
				$('.orderTabs').find('ul').append(_html);
				$('.orderTabs').tabs({
					beforeLoad : function(event, ui){
						$('.orderTabs').find('ul li').removeClass('active');
						$(ui.tab).addClass('active');
						var _tabId = $(ui.tab).attr('aria-controls');
						if(!$('#'+_tabId).is(':empty')){
							event.preventDefault();
		                    return;
		                }
					}
				});	
			},function(data){
				//window.location.href=contextPath+"/projectInitDetails.jsp?nfid="+_nfid+"&uuiFlag=true";
			});
		},
		getSortedTabs : function(data, key){
			return data.sort(function (a, b) {
				console.log(a[key]+'--------------'+b[key]);
				var x = a[key];
				var y = b[key];
				return ((x < y) ? -1 : ((x > y) ? 1 : 0));
			});
		},
		findTabName : function(data,tabName){
			return data.find(function(tabs){
				return tabs.tabName === tabName;
			});
		},
		loadSummaryInIframe : function(tabName){
			var _data = JSON.parse(sessionStorage.tabDetails),_selectedTab = this.findTabName(_data.tabDetails,tabName),_externalUrl = _selectedTab.tabUrl;
			var _html = '<iframe name="summaryIframe" id="summaryIframe" src="'+_externalUrl+'" style="border:0px;overflow-y:hidden;width:100%; height:533px;"></iframe>';
			var _divId = tabName.replace(" ","");
			$('#decIframeSummary-'+_divId).append(_html);
			$('#decIframeSummary-'+_divId).prev().hide();
			//$('#summaryIframe').attr('src',_externalUrl);
		}
	};
};
String.prototype.removeSpecialChars = function(){
	return this.replace(/[^a-zA-Z ]/g, "");
}; 
(function($){
    $.fn.serializeObject = function(){

        var self = this,
            json = {},
            push_counters = {},
            patterns = {
                "validate": /^[a-zA-Z][a-zA-Z0-9_]*(?:\[(?:\d*|[a-zA-Z0-9_]+)\])*$/,
                "key":      /[a-zA-Z0-9_]+|(?=\[\])/g,
                "push":     /^$/,
                "fixed":    /^\d+$/,
                "named":    /^[a-zA-Z0-9_]+$/
            };


        this.build = function(base, key, value){
            base[key] = value;
            return base;
        };

        this.push_counter = function(key){
            if(push_counters[key] === undefined){ 
                push_counters[key] = 0;
            }
            return push_counters[key]++;
        };

        $.each($(this).serializeArray(), function(){

            // skip invalid keys
            if(!patterns.validate.test(this.name)){
                return;
            }

            var k,
                keys = this.name.match(patterns.key),
                merge = this.value,
                reverse_key = this.name;

            while((k = keys.pop()) !== undefined){

                // adjust reverse_key
                reverse_key = reverse_key.replace(new RegExp("\\[" + k + "\\]$"), '');

                // push
                if(k.match(patterns.push)){
                    merge = self.build([], self.push_counter(reverse_key), merge);
                }

                // fixed
                else if(k.match(patterns.fixed)){
                    merge = self.build([], k, merge);
                }

                // named
                else if(k.match(patterns.named)){
                    merge = self.build({}, k, merge);
                }
            }

            json = $.extend(true, json, merge);
        });

        return json;
    };
})(jQuery);
if (!Array.prototype.find) {
	  Object.defineProperty(Array.prototype, 'find', {
		  value: function(predicate) {
			  if (this == null) {
				  throw new TypeError('"this" is null or not defined');
			  }
			  var o = Object(this);
			  var len = o.length >>> 0;
			  if (typeof predicate !== 'function') {
				  throw new TypeError('predicate must be a function');
			  }
			  var thisArg = arguments[1];
			  var k = 0;
			  while (k < len) {
				  var kValue = o[k];
				  if (predicate.call(thisArg, kValue, k, o)) {
					  return kValue;
				  }
				  k++;
			  }
			  return undefined;
		  }
	  });
}